import fs from 'fs';
import path from 'path';
import {PNG} from 'pngjs';
import pixelmatch from 'pixelmatch';

const act = "D:/Pinpoint/node/actual";
const exp = "D:/Pinpoint/node/expected";


const diff = "D:/Pinpoint/node/diff";
const out = "D:/Pinpoint/node/diff-out.txt";

if (!fs.existsSync(diff)) {
    fs.mkdirSync(diff, { recursive: true });
}


fs.writeFileSync(out, "DIFFERENT PAGES REPORT\n");

function load(filepath) {
    const data = fs.readFileSync(filepath);
    return PNG.sync.read(data);
}

function imgcomp(actImg, expImg) {
  const img1 = load(actImg);
  const img2 = load(expImg);

  if (img1.width !== img2.width || img1.height !== img2.height) {
    throw new Error("Image size mismatch");
  }

  const MASK = {
    x: 248, 
    y: 132,
    width: 700 - 248,
    height: 165 - 132 
  };

  for (let y = MASK.y; y < MASK.y + MASK.height; y++) {
    for (let x = MASK.x; x < MASK.x + MASK.width; x++) {
      const idx = (y * img1.width + x) * 4;

      img2.data[idx]     = img1.data[idx]; 
      img2.data[idx + 1] = img1.data[idx + 1];
      img2.data[idx + 2] = img1.data[idx + 2]; 
      img2.data[idx + 3] = img1.data[idx + 3]; 
    }
  }

  const diffimage = new PNG({
    width: img1.width,
    height: img1.height
  });

  const diffpix = pixelmatch(
    img1.data,
    img2.data,
    diffimage.data,
    img1.width,
    img1.height,
    { threshold: 0.1 }
  );

  const total = img1.width * img1.height;
  const diffper = (diffpix / total) * 100;

  return { diffper, diffimage };
}

function compareimg() {
    const images = fs
    .readdirSync(act)
    .filter(file => file.endsWith(".png"))
    .sort();

    for (let i = 0; i < images.length; i++) {
        const pageNo = i + 1;
        const file = images[i];

        const actimg = path.join(act, file);
        const expimg = path.join(exp, file);
        const diffimgPath = path.join(diff, `page-${pageNo}-diff.png`);

        if (!fs.existsSync(expimg)) {
            fs.appendFileSync(out, `Page ${pageNo}: Expected image missing\n`);
            continue;
        }

         try {
            const { diffper, diffimage } = imgcomp(actimg, expimg);

            fs.writeFileSync(diffimgPath, PNG.sync.write(diffimage));

            if (diffper > 0) {
                fs.appendFileSync(out,`Page ${pageNo}: Difference found (${diffper.toFixed(4)}%)\n` );
                console.log(`Page ${pageNo}: DIFFERENT`);
            }
        } catch (e) {
            fs.appendFileSync(out, `Page ${pageNo}: Error - ${e.message}\n`);
        }
    }

    console.log("Comparison completed");
}

compareimg();