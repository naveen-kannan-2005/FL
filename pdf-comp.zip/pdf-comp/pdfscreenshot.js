import fs from 'fs';
import { createRequire } from 'module';
import { format } from 'path';
import { scale } from 'pdf-lib';
const req = createRequire(import.meta.url);
const pdf = req("pdf-poppler");

async function scrshot(inp,out) {

  fs.mkdirSync(out,{recursive:true});

  const opt ={
    format:"png",
    out_dir:out,
    out_prefix:"page",
    page:null,
    scale:5000
  };

  await pdf.convert(inp,opt);
  
}

scrshot("C:/Users/NKPeriyachi/Downloads/output_manual 2.pdf","D:/Pinpoint/node/actual");
scrshot("C:/Users/NKPeriyachi/Downloads/page_Output 1.PDF","D:/Pinpoint/node/expected");