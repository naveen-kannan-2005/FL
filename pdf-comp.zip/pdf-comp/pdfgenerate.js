import fs from 'fs';
import path from 'path';
import { PDFDocument } from 'pdf-lib';

const diffDir = 'D:/Pinpoint/node/diff';
const outputPdf = 'D:/Pinpoint/node/diff-report.pdf';

async function createDiffPdf() {
    const pdfDoc = await PDFDocument.create();

    const images = fs
        .readdirSync(diffDir)
        .filter(f => f.endsWith('.png'))
        .sort();

    if (images.length === 0) {
        console.log('No images found in diff folder');
        return;
    }

    for (const imgFile of images) {
        const imgPath = path.join(diffDir, imgFile);
        const imgBytes = fs.readFileSync(imgPath);

        const pngImage = await pdfDoc.embedPng(imgBytes);
        const { width, height } = pngImage.size();

        const page = pdfDoc.addPage([width, height]);
        page.drawImage(pngImage, {
            x: 0,
            y: 0,
            width,
            height
        });
    }

    const pdfBytes = await pdfDoc.save();
    fs.writeFileSync(outputPdf, pdfBytes);

    console.log(`Diff PDF created successfully: ${outputPdf}`);
}

createDiffPdf()