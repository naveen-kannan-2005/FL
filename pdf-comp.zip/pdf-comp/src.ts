import helper from './utils/help.ts';

const help = new helper();

await help.scrshot("C:/Users/NKPeriyachi/Downloads/Actual.pdf","D:/Pinpoint/node/actual");

await help.scrshot("C:/Users/NKPeriyachi/Downloads/Expected.pdf","D:/Pinpoint/node/expected");

await help.compareimg("D:/Pinpoint/node/actual","D:/Pinpoint/node/expected","D:/Pinpoint/node/diff","D:/Pinpoint/node/diff-out.txt");

await help.createDiffPdf("D:/Pinpoint/node/diff","D:/Pinpoint/node/diff-report.pdf","D:/Pinpoint/node/diff-out.txt");