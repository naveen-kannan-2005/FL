"use strict";
var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
var __generator = (this && this.__generator) || function (thisArg, body) {
    var _ = { label: 0, sent: function() { if (t[0] & 1) throw t[1]; return t[1]; }, trys: [], ops: [] }, f, y, t, g = Object.create((typeof Iterator === "function" ? Iterator : Object).prototype);
    return g.next = verb(0), g["throw"] = verb(1), g["return"] = verb(2), typeof Symbol === "function" && (g[Symbol.iterator] = function() { return this; }), g;
    function verb(n) { return function (v) { return step([n, v]); }; }
    function step(op) {
        if (f) throw new TypeError("Generator is already executing.");
        while (g && (g = 0, op[0] && (_ = 0)), _) try {
            if (f = 1, y && (t = op[0] & 2 ? y["return"] : op[0] ? y["throw"] || ((t = y["return"]) && t.call(y), 0) : y.next) && !(t = t.call(y, op[1])).done) return t;
            if (y = 0, t) op = [op[0] & 2, t.value];
            switch (op[0]) {
                case 0: case 1: t = op; break;
                case 4: _.label++; return { value: op[1], done: false };
                case 5: _.label++; y = op[1]; op = [0]; continue;
                case 7: op = _.ops.pop(); _.trys.pop(); continue;
                default:
                    if (!(t = _.trys, t = t.length > 0 && t[t.length - 1]) && (op[0] === 6 || op[0] === 2)) { _ = 0; continue; }
                    if (op[0] === 3 && (!t || (op[1] > t[0] && op[1] < t[3]))) { _.label = op[1]; break; }
                    if (op[0] === 6 && _.label < t[1]) { _.label = t[1]; t = op; break; }
                    if (t && _.label < t[2]) { _.label = t[2]; _.ops.push(op); break; }
                    if (t[2]) _.ops.pop();
                    _.trys.pop(); continue;
            }
            op = body.call(thisArg, _);
        } catch (e) { op = [6, e]; y = 0; } finally { f = t = 0; }
        if (op[0] & 5) throw op[1]; return { value: op[0] ? op[1] : void 0, done: true };
    }
};
Object.defineProperty(exports, "__esModule", { value: true });
var fs_1 = require("fs");
var module_1 = require("module");
var path_1 = require("path");
var pdf_lib_1 = require("pdf-lib");
var pngjs_1 = require("pngjs");
var pixelmatch_1 = require("pixelmatch");
var req = (0, module_1.createRequire)(import.meta.url);
var pdf = req("pdf-poppler");
var helper = /** @class */ (function () {
    function helper() {
    }
    helper.prototype.scrshot = function (inp, out) {
        return __awaiter(this, void 0, void 0, function () {
            var opt;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0:
                        fs_1.default.mkdirSync(out, { recursive: true });
                        opt = {
                            format: "png",
                            out_dir: out,
                            out_prefix: "page",
                            page: null,
                            scale: 5000
                        };
                        return [4 /*yield*/, pdf.convert(inp, opt)];
                    case 1:
                        _a.sent();
                        console.log("it is completed");
                        return [2 /*return*/];
                }
            });
        });
    };
    helper.prototype.fileexist = function (input) {
        return __awaiter(this, void 0, void 0, function () {
            return __generator(this, function (_a) {
                if (!fs_1.default.existsSync(input)) {
                    fs_1.default.mkdirSync(input, { recursive: true });
                }
                return [2 /*return*/];
            });
        });
    };
    helper.prototype.load = function (filepath) {
        return __awaiter(this, void 0, void 0, function () {
            var data;
            return __generator(this, function (_a) {
                data = fs_1.default.readFileSync(filepath);
                return [2 /*return*/, pngjs_1.PNG.sync.read(data)];
            });
        });
    };
    helper.prototype.imgcomp = function (actImg, expImg) {
        return __awaiter(this, void 0, void 0, function () {
            var img1, img2, MASK, y, x, idx, diffimage, diffpix, total, diffper;
            return __generator(this, function (_a) {
                switch (_a.label) {
                    case 0: return [4 /*yield*/, this.load(actImg)];
                    case 1:
                        img1 = _a.sent();
                        return [4 /*yield*/, this.load(expImg)];
                    case 2:
                        img2 = _a.sent();
                        if (img1.width !== img2.width || img1.height !== img2.height) {
                            throw new Error("Image size mismatch");
                        }
                        MASK = {
                            x: 248,
                            y: 132,
                            width: 700 - 248,
                            height: 165 - 132
                        };
                        for (y = MASK.y; y < MASK.y + MASK.height; y++) {
                            for (x = MASK.x; x < MASK.x + MASK.width; x++) {
                                idx = (y * img1.width + x) * 4;
                                img2.data[idx] = img1.data[idx];
                                img2.data[idx + 1] = img1.data[idx + 1];
                                img2.data[idx + 2] = img1.data[idx + 2];
                                img2.data[idx + 3] = img1.data[idx + 3];
                            }
                        }
                        diffimage = new pngjs_1.PNG({
                            width: img1.width,
                            height: img1.height
                        });
                        diffpix = (0, pixelmatch_1.default)(img1.data, img2.data, diffimage.data, img1.width, img1.height, { threshold: 0.1 });
                        total = img1.width * img1.height;
                        diffper = (diffpix / total) * 100;
                        return [2 /*return*/, { diffper: diffper, diffimage: diffimage }];
                }
            });
        });
    };
    helper.prototype.compareimg = function (act, exp, diff, out) {
        return __awaiter(this, void 0, void 0, function () {
            var images, i, pageNo, file, actimg, expimg, diffimgPath, _a, diffper, diffimage, e_1;
            return __generator(this, function (_b) {
                switch (_b.label) {
                    case 0:
                        images = fs_1.default
                            .readdirSync(act)
                            .filter(function (file) { return file.endsWith(".png"); })
                            .sort();
                        return [4 /*yield*/, this.fileexist(diff)];
                    case 1:
                        _b.sent();
                        i = 0;
                        _b.label = 2;
                    case 2:
                        if (!(i < images.length)) return [3 /*break*/, 7];
                        pageNo = i + 1;
                        file = images[i];
                        actimg = path_1.default.join(act, file);
                        expimg = path_1.default.join(exp, file);
                        diffimgPath = path_1.default.join(diff, "page-".concat(pageNo, "-diff.png"));
                        if (!fs_1.default.existsSync(expimg)) {
                            fs_1.default.appendFileSync(out, "Page ".concat(pageNo, ": Expected image missing\n"));
                            return [3 /*break*/, 6];
                        }
                        _b.label = 3;
                    case 3:
                        _b.trys.push([3, 5, , 6]);
                        return [4 /*yield*/, this.imgcomp(actimg, expimg)];
                    case 4:
                        _a = _b.sent(), diffper = _a.diffper, diffimage = _a.diffimage;
                        fs_1.default.writeFileSync(diffimgPath, pngjs_1.PNG.sync.write(diffimage));
                        if (diffper > 0) {
                            fs_1.default.appendFileSync(out, "Page ".concat(pageNo, ": Difference found (").concat(diffper.toFixed(4), "%)\n"));
                            console.log("Page ".concat(pageNo, ": DIFFERENT"));
                        }
                        return [3 /*break*/, 6];
                    case 5:
                        e_1 = _b.sent();
                        fs_1.default.appendFileSync(out, "Page ".concat(pageNo, ": Error - ").concat(e_1.message, "\n"));
                        return [3 /*break*/, 6];
                    case 6:
                        i++;
                        return [3 /*break*/, 2];
                    case 7:
                        console.log("Comparison completed");
                        return [2 /*return*/];
                }
            });
        });
    };
    helper.prototype.createDiffPdf = function (diffDir, outputPdf, logFilePath) {
        return __awaiter(this, void 0, void 0, function () {
            var pdfDoc, images, firstImgPath, firstImgData, firstPng, _a, width, height, summaryPage, titleSize, textSize, yOffset, logContent, lines, _i, lines_1, line, _b, images_1, imgFile, imgPath, imgBytes, pngImage, page, pdfBytes;
            return __generator(this, function (_c) {
                switch (_c.label) {
                    case 0: return [4 /*yield*/, pdf_lib_1.PDFDocument.create()];
                    case 1:
                        pdfDoc = _c.sent();
                        images = fs_1.default
                            .readdirSync(diffDir)
                            .filter(function (f) { return f.endsWith(".png"); })
                            .sort(function (a, b) { return a.localeCompare(b, undefined, { numeric: true }); });
                        if (images.length === 0) {
                            console.log("No images found in diff folder");
                            return [2 /*return*/];
                        }
                        firstImgPath = path_1.default.join(diffDir, images[0]);
                        firstImgData = fs_1.default.readFileSync(firstImgPath);
                        return [4 /*yield*/, pdfDoc.embedPng(firstImgData)];
                    case 2:
                        firstPng = _c.sent();
                        _a = firstPng.size(), width = _a.width, height = _a.height;
                        summaryPage = pdfDoc.addPage([width, height]);
                        titleSize = Math.round(width / 30);
                        textSize = Math.round(width / 60);
                        yOffset = height - (height / 10);
                        summaryPage.drawText("PDF Comparison Report Summary", {
                            x: 50,
                            y: yOffset,
                            size: titleSize
                        });
                        yOffset -= (titleSize * 2);
                        if (fs_1.default.existsSync(logFilePath)) {
                            logContent = fs_1.default.readFileSync(logFilePath, "utf-8");
                            lines = logContent.split("\n");
                            for (_i = 0, lines_1 = lines; _i < lines_1.length; _i++) {
                                line = lines_1[_i];
                                if (yOffset < 50)
                                    break;
                                summaryPage.drawText(line.trim(), {
                                    x: 50,
                                    y: yOffset,
                                    size: textSize,
                                    lineHeight: textSize * 1.5
                                });
                                yOffset -= (textSize * 2);
                            }
                        }
                        _b = 0, images_1 = images;
                        _c.label = 3;
                    case 3:
                        if (!(_b < images_1.length)) return [3 /*break*/, 6];
                        imgFile = images_1[_b];
                        imgPath = path_1.default.join(diffDir, imgFile);
                        imgBytes = fs_1.default.readFileSync(imgPath);
                        return [4 /*yield*/, pdfDoc.embedPng(imgBytes)];
                    case 4:
                        pngImage = _c.sent();
                        page = pdfDoc.addPage([pngImage.width, pngImage.height]);
                        page.drawImage(pngImage, {
                            x: 0,
                            y: 0,
                            width: pngImage.width,
                            height: pngImage.height,
                        });
                        _c.label = 5;
                    case 5:
                        _b++;
                        return [3 /*break*/, 3];
                    case 6: return [4 /*yield*/, pdfDoc.save()];
                    case 7:
                        pdfBytes = _c.sent();
                        fs_1.default.writeFileSync(outputPdf, pdfBytes);
                        console.log("Diff PDF created with uniform page sizes.");
                        return [2 /*return*/];
                }
            });
        });
    };
    return helper;
}());
exports.default = helper;
