import fs from "fs";
import { createRequire } from "module";
import path from "path";
import { PDFDocument } from "pdf-lib";
import { PNG } from "pngjs";
import pixelmatch from "pixelmatch";

const req = createRequire(import.meta.url);
const pdf = req("pdf-poppler");


export default class helper {
  async scrshot(inp: string, out: string): Promise<void> {
    fs.mkdirSync(out, { recursive: true });

    const opt = {
      format: "png",
      out_dir: out,
      out_prefix: "page",
      page: null,
      scale: 5000
    };

    await pdf.convert(inp, opt);
    console.log("it is completed");
  }

  async fileexist(input: string): Promise<void> {
    if (!fs.existsSync(input)) {
      fs.mkdirSync(input, { recursive: true });
    }
  }

  async load(filepath: string): Promise<PNG> {
    const data = fs.readFileSync(filepath);
    return PNG.sync.read(data);
  }

  async copypix(img1:PNG,img2:PNG){
    const MASK = {
      x: 248,
      y: 132,
      width: 700 - 248,
      height: 165 - 132
    };

    for (let y = MASK.y; y < MASK.y + MASK.height; y++) {
      for (let x = MASK.x; x < MASK.x + MASK.width; x++) {
        const idx = (y * img1.width + x) * 4;

        img2.data[idx] = img1.data[idx];
        img2.data[idx + 1] = img1.data[idx + 1];
        img2.data[idx + 2] = img1.data[idx + 2];
        img2.data[idx + 3] = img1.data[idx + 3];
      }
    }

  }

  async imgsize(img1:PNG,img2:PNG){
    if (img1.width !== img2.width || img1.height !== img2.height) {
      throw new Error("Image size mismatch");
    }
  }

  async imgcomp(actImg: string, expImg: string): Promise<{ diffper: number; diffimage: PNG }> {
    const img1 = await this.load(actImg);
    const img2 = await this.load(expImg);

    await this.imgsize(img1,img2);
    await this.copypix(img1,img2);

    const diffimage = new PNG({
      width: img1.width,
      height: img1.height
    });

    const diffpix = pixelmatch(
      img1.data,
      img2.data,
      diffimage.data,
      img1.width,
      img1.height,
      { threshold: 0.1 }
    );

    const total = img1.width * img1.height;
    const diffper = (diffpix / total) * 100;

    return { diffper, diffimage };
  }

  async compareimg(act: string,exp: string,diff: string,out: string): Promise<void> {
    const images = fs
      .readdirSync(act)
      .filter(file => file.endsWith(".png"))
      .sort();

      await this.fileexist(diff);
      fs.writeFileSync(out,'');

    for (let i = 0; i < images.length; i++) {
      const pageNo = i + 1;
      const file = images[i];

      const actimg = path.join(act, file);
      const expimg = path.join(exp, file);
      const diffimgPath = path.join(diff, `page-${pageNo}-diff.png`);

      if (!fs.existsSync(expimg)) {
        fs.appendFileSync(out, `Page ${pageNo}: Expected image missing\n`);
        continue;
      }

      try {
        const { diffper, diffimage } = await this.imgcomp(actimg, expimg);

        fs.writeFileSync(diffimgPath, PNG.sync.write(diffimage));

        if (diffper > 0) {
          fs.appendFileSync(out,`Page ${pageNo}: Difference found (${diffper.toFixed(4)}%)\n`);
          console.log(`Page ${pageNo}: DIFFERENT`);
        }
      } catch (e: any) {
        console.log(e);
        fs.appendFileSync(out, `Page ${pageNo}: Error - ${e.message}\n`);
      }
    }

    console.log("Comparison completed");
  }

  async createDiffPdf(diffDir: string, outputPdf: string, logFilePath: string): Promise<void> {
    const pdfDoc = await PDFDocument.create();

    const images = fs
      .readdirSync(diffDir)
      .filter((f) => f.endsWith(".png"))
      .sort((a, b) => a.localeCompare(b, undefined, { numeric: true }));

    if (images.length === 0) {
      console.log("No images found in diff folder");
      return;
    }

    
    const firstImgPath = path.join(diffDir, images[0]);
    const firstImgData = fs.readFileSync(firstImgPath);
    const firstPng = await pdfDoc.embedPng(firstImgData);
    const { width, height } = firstPng.size();


    let summaryPage = pdfDoc.addPage([width, height]);

    
    const titleSize = Math.round(width / 30); 
    const textSize = Math.round(width / 60);
    let yOffset = height - (height / 10)


    summaryPage.drawText("PDF Comparison Report Summary", { 
        x: 50, 
        y: yOffset, 
        size: titleSize 
    });
    
    yOffset -= (titleSize * 2);

    if (fs.existsSync(logFilePath)) {
      const logContent = fs.readFileSync(logFilePath, "utf-8");
      const lines = logContent.split("\n");

      for (const line of lines) {
        
        if (yOffset < 50) {
          summaryPage = pdfDoc.addPage([width, height]);
          yOffset = height - (height / 10);
        }
 
        summaryPage.drawText(line.trim(), {
          x: 50,
          y: yOffset,
          size: textSize,
          lineHeight: textSize * 1.5
        });
        yOffset -= (textSize * 2);
      }
    }

    for (const imgFile of images) {
      const imgPath = path.join(diffDir, imgFile);
      const imgBytes = fs.readFileSync(imgPath);
      const pngImage = await pdfDoc.embedPng(imgBytes);

      const page = pdfDoc.addPage([pngImage.width, pngImage.height]);
      page.drawImage(pngImage, {
        x: 0,
        y: 0,
        width: pngImage.width,
        height: pngImage.height,
      });
    }

    const pdfBytes = await pdfDoc.save();
    fs.writeFileSync(outputPdf, pdfBytes);
    console.log("Diff PDF created with uniform page sizes.");
}
}

