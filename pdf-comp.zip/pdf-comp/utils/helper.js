import fs from 'fs';
import { createRequire } from 'module';
import path, {  format } from 'path';
import { scale , PDFDocument} from 'pdf-lib';
const req = createRequire(import.meta.url);
const pdf = req("pdf-poppler");
import { PDFParse } from "pdf-parse";
import { diffLines } from "diff";
import {PNG} from 'pngjs';
import pixelmatch from 'pixelmatch';

export default class helper{

    async scrshot(inp,out) {
        fs.mkdirSync(out,{recursive:true});
        const opt = {
            format : 'png',
            out_dir : out,
            out_prefix : 'page',
            page : null,
            scale : 5000
        }
        await pdf.convert(inp,opt);
        console.log("it is completed");
    }

    async fileexist(input){
        if (!fs.existsSync(input)) {
            fs.mkdirSync(input, { recursive: true });
        }
    }
    async load(filepath) {
        const data = fs.readFileSync(filepath);
        return PNG.sync.read(data);
    }
    
    async imgcomp(actImg, expImg) {
      const img1 = await this.load(actImg);
      const img2 = await this.load(expImg);
    
      if (img1.width !== img2.width || img1.height !== img2.height) {
        throw new Error("Image size mismatch");
      }
    
      const MASK = {
        x: 248, 
        y: 132,
        width: 700 - 248,
        height: 165 - 132 
      };
    
      for (let y = MASK.y; y < MASK.y + MASK.height; y++) {
        for (let x = MASK.x; x < MASK.x + MASK.width; x++) {
          const idx = (y * img1.width + x) * 4;
    
          img2.data[idx]     = img1.data[idx]; 
          img2.data[idx + 1] = img1.data[idx + 1];
          img2.data[idx + 2] = img1.data[idx + 2]; 
          img2.data[idx + 3] = img1.data[idx + 3]; 
        }
      }
    
      const diffimage = new PNG({
        width: img1.width,
        height: img1.height
      });
    
      const diffpix = pixelmatch(
        img1.data,
        img2.data,
        diffimage.data,
        img1.width,
        img1.height,
        { threshold: 0.1 }
      );
    
      const total = img1.width * img1.height;
      const diffper = (diffpix / total) * 100;
    
      return { diffper, diffimage };
    }

    async compareimg(act,exp,diff,out) {
        const images = await fs
        .readdirSync(act)
        .filter(file => file.endsWith(".png"))
        .sort();
    
        for (let i = 0; i < images.length; i++) {
            const pageNo = i + 1;
            const file = images[i];
    
            const actimg = path.join(act, file);
            const expimg = path.join(exp, file);
            const diffimgPath = path.join(diff, `page-${pageNo}-diff.png`);
    
            if (!fs.existsSync(expimg)) {
                fs.appendFileSync(out, `Page ${pageNo}: Expected image missing\n`);
                continue;
            }
    
             try {
                const { diffper, diffimage } = await this.imgcomp(actimg, expimg);
    
                fs.writeFileSync(diffimgPath, PNG.sync.write(diffimage));
    
                if (diffper > 0) {
                    fs.appendFileSync(out,`Page ${pageNo}: Difference found (${diffper.toFixed(4)}%)\n` );
                    console.log(`Page ${pageNo}: DIFFERENT`);
                }
            } catch (e) {
                fs.appendFileSync(out, `Page ${pageNo}: Error - ${e.message}\n`);
            }
        }
    
        console.log("Comparison completed");
    }
    async createDiffPdf(diffDir,outputPdf) {
        const pdfDoc = await PDFDocument.create();
    
        const images = await fs
            .readdirSync(diffDir)
            .filter(f => f.endsWith('.png'))
            .sort();
    
        if (images.length === 0) {
            console.log('No images found in diff folder');
            return;
        }
    
        for (const imgFile of images) {
            const imgPath = path.join(diffDir, imgFile);
            const imgBytes = fs.readFileSync(imgPath);
    
            const pngImage = await pdfDoc.embedPng(imgBytes);
            const { width, height } = pngImage.size();
    
            const page = pdfDoc.addPage([width, height]);
            page.drawImage(pngImage, {
                x: 0,
                y: 0,
                width,
                height
            });
        }
    
        const pdfBytes = await pdfDoc.save();
        fs.writeFileSync(outputPdf, pdfBytes);
    
        console.log(`Diff PDF created successfully`);
    }
    
}