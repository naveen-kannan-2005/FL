import { test, expect } from "@playwright/test";
import fs from "node:fs";
import path from "node:path";
import data from "../data/data.json" assert { type: "json" };
import * as H from "../utils/helper.ts";

test("PDF validations", async () => {
  // Non-function calls (no try/catch)
  expect(fs.existsSync(data.actualPdf)).toBeTruthy();
  expect(fs.existsSync(data.expectedPdf)).toBeTruthy();

  fs.mkdirSync(data.out.actualDir, { recursive: true });
  fs.mkdirSync(data.out.expectedDir, { recursive: true });
  fs.mkdirSync(data.out.compareDir, { recursive: true });

  const tessFile = path.join(data.internalLinks.tessDataPath, "eng.traineddata");
  const hasTess = fs.existsSync(tessFile);

  // ✅ one wrapper: try/catch ONLY for helper function calls
  const run = async <T extends { pass?: boolean }>(step: string, fn: () => Promise<T>) => {
    try {
      const res = await fn();

      // print full details if FAIL
      if (res && typeof res.pass === "boolean" && res.pass === false) {
        console.log(`\n========== ❌ FAIL DETAILS: ${step} ==========\n`);
        console.dir(res, { depth: null, colors: true });
        console.log(`\n========== END FAIL DETAILS: ${step} ==========\n`);
      }

      // soft assert if pass exists
      if (res && typeof res.pass === "boolean") {
        expect.soft(res.pass, `${step} returned pass=false`).toBeTruthy();
      }

      return res;
    } catch (e: any) {
      console.log(`\n========== ❌ EXCEPTION: ${step} ==========\n`);
      console.log(e?.stack || e?.message || String(e));
      console.log(`\n========== END EXCEPTION: ${step} ==========\n`);
      expect.soft(false, `${step} threw error`).toBeTruthy();
      return null;
    }
  };

  // 1) Printed / Revision
  await run("validatePdf(actual)", () => H.validatePdf(data.actualPdf));
  await run("validatePdf(expected)", () => H.validatePdf(data.expectedPdf));

  // 2) Internal Links
  if (hasTess) {
    await run("validateInternalLinks(actual)", () => H.validateInternalLinks(data.actualPdf, data.internalLinks));
    await run("validateInternalLinks(expected)", () => H.validateInternalLinks(data.expectedPdf, data.internalLinks));
  } else {
    console.log("Skipping Internal Links (missing tessdata): " + tessFile);
  }

  // 3) Station
  await run("validateStation(actual)", () => H.validateStation(data.actualPdf, data.station.expected, data.station.headerPct));
  await run("validateStation(expected)", () => H.validateStation(data.expectedPdf, data.station.expected, data.station.headerPct));

  // 4) Date Completed
  await run("validateDateCompletedRegex(actual)", () => H.validateDateCompletedRegex(data.actualPdf, data.dateCompleted.pageNo, data.dateCompleted.topKeepRatio));
  await run("validateDateCompletedRegex(expected)", () => H.validateDateCompletedRegex(data.expectedPdf, data.dateCompleted.pageNo, data.dateCompleted.topKeepRatio));

  // 5) Outline
  await run("validateOutlineMarkers(actual)", () => H.validateOutlineMarkers(data.actualPdf, data.outline.firstLevel));
  await run("validateOutlineMarkers(expected)", () => H.validateOutlineMarkers(data.expectedPdf, data.outline.firstLevel));

  // 6) Board Copy (Heavy only)
  if (data.Preview?.Loc === "Heavy") {
    await run("validateBoardCopy(actual)", () => H.validateBoardCopy(data.actualPdf, data.boardCopy.phrase, data.boardCopy.topKeepRatio));
    await run("validateBoardCopy(expected)", () => H.validateBoardCopy(data.expectedPdf, data.boardCopy.phrase, data.boardCopy.topKeepRatio));
  }

  // 11) Effectivity (Soft only)
  if (data.Preview?.Loc === "Soft") {
    await run("validateEffectivitySoft(actual)", () => H.validateEffectivitySoft(data.actualPdf));
    await run("validateEffectivitySoft(expected)", () => H.validateEffectivitySoft(data.expectedPdf));
  }

  // 7) Search
  await run("searchPdfText(actual)", () => H.searchPdfText(data.actualPdf, data.search.query));
  await run("searchPdfText(expected)", () => H.searchPdfText(data.expectedPdf, data.search.query));

  // 8) Export Figures + 9) Compare Figures
  if (hasTess) {
    const actFigDir = path.join(data.out.actualDir, data.figures.subDir);
    const expFigDir = path.join(data.out.expectedDir, data.figures.subDir);
    const diffDir = path.join(data.out.compareDir, data.figures.diffSubDir);

    fs.mkdirSync(actFigDir, { recursive: true });
    fs.mkdirSync(expFigDir, { recursive: true });
    fs.mkdirSync(diffDir, { recursive: true });

    const aFigs = await run("exportLinkedFigures(actual)", () =>
      H.exportLinkedFigures(
        data.actualPdf,
        actFigDir,
        data.figures.scale,
        data.figures.headerPct,
        data.figures.footerPct,
        data.internalLinks.tessDataPath
      )
    );

    const eFigs = await run("exportLinkedFigures(expected)", () =>
      H.exportLinkedFigures(
        data.expectedPdf,
        expFigDir,
        data.figures.scale,
        data.figures.headerPct,
        data.figures.footerPct,
        data.internalLinks.tessDataPath
      )
    );

    if (aFigs?.pass && eFigs?.pass) {
      await run("compareFigureImages(expected vs actual)", () => H.compareFigureImages(expFigDir, actFigDir, diffDir));
    } else {
      console.log("Skipping compareFigureImages because figure export failed.");
      expect.soft(false, "Figure export failed; comparison skipped").toBeTruthy();
    }
  } else {
    console.log("Skipping Figures Export/Compare (missing tessdata): " + tessFile);
  }

  // 10) Margins
  await run("validateMargins(actual)", () => H.validateMargins(data.actualPdf, data.margins));
  await run("validateMargins(expected)", () => H.validateMargins(data.expectedPdf, data.margins));
});