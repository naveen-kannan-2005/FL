import fs from "node:fs";
import path from "node:path";
import * as pdfjs from "pdfjs-dist/legacy/build/pdf.mjs";
import { createCanvas, type ImageData as CanvasImageData } from "@napi-rs/canvas";
import { createWorker } from "tesseract.js";
import { createRequire } from "node:module";
import help from "../data/help.json" assert { type: "json" };

const _req = createRequire(import.meta.url);

/* ===================== tiny helpers ===================== */
const RX = (name: "printed" | "revision" | "dateCompleted") => {
  const r = (help as any).regex?.[name];
  return new RegExp(r?.pattern || "", r?.flags || "");
};
export function T(name: "INDENT_TOL" | "SAME_TOL" | "LINE_Y_TOL") {
  return Number((help as any).outlineTolerances?.[name] ?? 0);
}

export function isBlue(r: number, g: number, b: number) {
  return b > 120 && b > r + 40 && b > g + 40;
}

export async function loadPdfDoc(p: string, opts: any = {}) {
  const data = new Uint8Array(fs.readFileSync(p));
  return pdfjs.getDocument({ data, ...opts }).promise;
}

export function ensureDir(d: string) {
  fs.mkdirSync(d, { recursive: true });
}
async function renderPageToCanvas(page: any, scale: number) {
  const v = page.getViewport({ scale });
  const canvas = createCanvas(Math.ceil(v.width), Math.ceil(v.height));
  const ctx = canvas.getContext("2d");
  await (page as any).render({ canvasContext: ctx as any, canvas: canvas as any, viewport: v } as any).promise;
  return { canvas, ctx, viewport: v };
}

function computeRect(v: any, rect: any, canvas: any) {
  const r = v.convertToViewportRectangle(rect);
  const x1 = Math.min(r[0], r[2]), x2 = Math.max(r[0], r[2]);
  const y1 = Math.min(r[1], r[3]), y2 = Math.max(r[1], r[3]);
  const x = Math.max(0, Math.floor(x1)), y = Math.max(0, Math.floor(y1));
  const w = Math.min(canvas.width - x, Math.ceil(x2 - x1));
  const h = Math.min(canvas.height - y, Math.ceil(y2 - y1));
  return { x, y, w, h };
}

function calcBlueRatio(ctx: any, x: number, y: number, w: number, h: number) {
  const img = ctx.getImageData(x, y, w, h).data;
  let blue = 0;
  for (let i = 0; i < img.length; i += 4) if (img[i + 3] && isBlue(img[i], img[i + 1], img[i + 2])) blue++;
  return blue / (w * h || 1);
}

async function ocrCrop(worker: any, canvas: any, x: number, y: number, w: number, h: number) {
  const crop = createCanvas(w, h);
  crop.getContext("2d").drawImage(canvas as any, x, y, w, h, 0, 0, w, h);
  const res = await worker.recognize(crop.toBuffer("image/png"));
  return String(res.data.text || "").replace(/\s+/g, " ").trim();
}

async function resolveDestPage(pdf: any, dest: any) {
  let d = dest;
  if (typeof d === "string") d = await pdf.getDestination(d);
  try { return (await pdf.getPageIndex(d[0])) + 1; } catch { return null; }
}

/* ===================== 1) Printed/Revision Date ===================== */
function getText(items: any[], minY: number, maxY: number) {
  return (items || [])
    .filter((it: any) => it?.str && typeof it?.transform?.[5] === "number")
    .filter((it: any) => it.transform[5] >= minY && it.transform[5] <= maxY)
    .map((it: any) => String(it.str))
    .join(" ").replace(/\s+/g, " ").trim();
}

export async function validatePdf(pdfPath: string) {
  if (!fs.existsSync(pdfPath)) throw new Error("PDF not found");
  const printed = RX("printed"), revision = RX("revision");
  const pdf: any = await loadPdfDoc(pdfPath, { disableWorker: true });

  let basePrinted = "", baseRevision = "";
  const missingPrinted: number[] = [], missingRevision: number[] = [];
  const mismatch = new Set<number>();

  try {
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const tc = await page.getTextContent();
      const h = page?.view?.[3] ?? page.getViewport({ scale: 1 }).height;

      const header = getText(tc.items, h * 0.9, h);
      const footer = getText(tc.items, 0, h * 0.1);

      const p = footer.match(printed)?.[0] || "";
      const r = header.match(revision)?.[0] || "";

      if (!p) missingPrinted.push(i);
      else if (!basePrinted) basePrinted = p;
      else if (p !== basePrinted) mismatch.add(i);

      if (!r) missingRevision.push(i);
      else if (!baseRevision) baseRevision = r;
      else if (r !== baseRevision) mismatch.add(i);
    }

    const mismatchPages = [...mismatch].sort((a, b) => a - b);
    const pass = !!basePrinted && !!baseRevision && !missingPrinted.length && !missingRevision.length && !mismatchPages.length;

    console.log(pass ? "✅ PASS (Printed/Revision)" : "❌ FAIL (Printed/Revision)");
    return { pass, totalPages: pdf.numPages, baselinePrinted: basePrinted || null, baselineRevision: baseRevision || null, missingPrintedPages: missingPrinted, missingRevisionPages: missingRevision, mismatchPages };
  } finally { await (pdf as any)?.destroy?.(); }
}

/* ===================== 2) Internal Links (OCR) ===================== */
export type InternalLinkOptions = { scale?: number; blueThreshold?: number; tessDataPath?: string };
const internalDefaults: Required<InternalLinkOptions> = { scale: 4, blueThreshold: 0.001, tessDataPath: "./tessdata" };

export async function validateInternalLinks(pdfPath: string, opts?: InternalLinkOptions) {
  const { scale, blueThreshold, tessDataPath } = { ...internalDefaults, ...(opts || {}) };

  if (!fs.existsSync(pdfPath)) {
    console.log("❌ FAIL (Internal Links) - PDF not found");
    return { pass: false, total: 0, failed: 0, failures: [] as any[] };
  }
  if (!fs.existsSync(path.join(tessDataPath, "eng.traineddata"))) {
    console.log("❌ FAIL (Internal Links) - Missing eng.traineddata");
    return { pass: false, total: 0, failed: 0, failures: [] as any[] };
  }

  const pdf: any = await loadPdfDoc(pdfPath, { verbosity: 0 });
  const worker = await createWorker("eng", undefined, { langPath: tessDataPath, gzip: false, logger: () => {} });

  let total = 0, failed = 0;
  const failures: Array<{ page: number; destPage: number | null; blueRatio: number | null; ocrText: string; reason: string[] }> = [];

  try {
    for (let p = 1; p <= pdf.numPages; p++) {
      const page = await pdf.getPage(p);
      const { canvas, ctx, viewport } = await renderPageToCanvas(page, scale);
      const annots = await page.getAnnotations();
      const links = (annots || []).filter((x: any) => x.subtype === "Link" && x.dest && !(x.url || x.unsafeUrl));

      for (const a of links) {
        total++;
        const reason: string[] = [];
        const destPage = await resolveDestPage(pdf, a.dest);
        if (!destPage) reason.push("destination broken");

        if (!a.rect || a.rect.length !== 4) {
          reason.push("rect missing");
          failed++;
          failures.push({ page: p, destPage, blueRatio: null, ocrText: "", reason });
          continue;
        }

        const { x, y, w, h } = computeRect(viewport, a.rect, canvas);
        const blueRatio = calcBlueRatio(ctx, x, y, w, h);
        if (blueRatio < blueThreshold) reason.push(`not blue (${blueRatio.toFixed(4)})`);

        const ocrText = await ocrCrop(worker, canvas, x, y, w, h);
        if (reason.length) { failed++; failures.push({ page: p, destPage, blueRatio, ocrText, reason }); }
      }
    }

    const pass = total === 0 || failed === 0;
    console.log(pass ? "✅ PASS (Internal Links)" : `❌ FAIL (Internal Links) - ${failed}/${total}`);
    return { pass, total, failed, failures };
  } finally { await worker.terminate(); await (pdf as any)?.destroy?.(); }
}

/* ===================== 3) Station ===================== */
export async function validateStation(pdfPath: string, expected = "", headerPct = 0.1) {
  if (!fs.existsSync(pdfPath)) {
    console.log("❌ FAIL (Station) - PDF not found");
    return { pass: false, station: "MISSING", expected: expected.toUpperCase() };
  }

  const pdf: any = await loadPdfDoc(pdfPath);
  let station = "MISSING";

  try {
    for (let i = 1; i <= pdf.numPages; i++) {
      const page = await pdf.getPage(i);
      const h = page.getViewport({ scale: 1 }).height;
      const cut = h * headerPct;
      const t = await page.getTextContent();

      const header = (t.items as any[])
        .filter(it => it.str && it.transform?.[5] >= h - cut)
        .map(it => String(it.str).trim())
        .join(" ").replace(/\s+/g, " ").trim();

      const m = header.match(/Station:\s*([A-Za-z0-9_-]+)/i);
      if (m) { station = m[1].toUpperCase(); break; }
    }
  } finally { await (pdf as any)?.destroy?.(); }

  const exp = (expected || "").toUpperCase();
  const pass = station !== "MISSING" && (!exp || station === exp);
  console.log(pass ? "✅ PASS (Station)" : `❌ FAIL (Station) - Found=${station}, Expected=${exp || "NOT_GIVEN"}`);
  return { pass, station, expected: exp };
}

/* ===================== 4) Date Completed ===================== */
function groupByLine(items: any[]) {
  const m = new Map<number, any[]>();
  for (const t of items) {
    const y = Math.round(t.y / 2) * 2;
    if (!m.has(y)) m.set(y, []);
    m.get(y)!.push(t);
  }
  return m;
}
function buildLines(lineMap: Map<number, any[]>) {
  return [...lineMap.keys()]
    .sort((a, b) => b - a)
    .map(y => lineMap.get(y)!.sort((a, b) => a.x - b.x).map(z => z.s).join(" ").replace(/\s+/g, " ").trim());
}
function findMatchedLine(lines: string[]) {
  const re = RX("dateCompleted");
  return lines.find(l => re.test(l)) || "";
}

export async function validateDateCompletedRegex(pdfPath: string, pageNo = 1, topKeepRatio = 0.75) {
  if (!fs.existsSync(pdfPath)) {
    console.log("❌ FAIL (Date Completed) - PDF not found");
    return { pass: false, matchedLine: "" };
  }

  const doc: any = await loadPdfDoc(pdfPath, { disableWorker: true });
  try {
    const pg = Math.min(Math.max(1, pageNo), doc.numPages);
    const page = await doc.getPage(pg);
    const cutY = page.getViewport({ scale: 1 }).height * topKeepRatio;
    const tc = await page.getTextContent();

    const items = (tc.items || [])
      .map((it: any) => ({ s: (it.str || "").trim(), x: it.transform?.[4] || 0, y: it.transform?.[5] || 0 }))
      .filter((t: any) => t.s && t.y >= cutY);

    const matchedLine = findMatchedLine(buildLines(groupByLine(items)));
    const pass = !!matchedLine;

    console.log(pass ? "✅ PASS (Date Completed)" : "❌ FAIL (Date Completed)");
    return { pass, matchedLine };
  } finally { await (doc as any)?.destroy?.(); }
}

/* ===================== 5) Outline Markers ===================== */
const normalize = (s: string) => s.replace(/\s+/g, " ").trim();
const nextLetter = (ch: string) => String.fromCharCode(ch.charCodeAt(0) + 1);
const expectedKind = (first: "NUM" | "ALPHA", depth: number): "NUM" | "ALPHA" => (depth % 2 === 0 ? first : first === "NUM" ? "ALPHA" : "NUM");

async function extractLines(page: any) {
  const tc = await page.getTextContent();
  const items = (tc.items || [])
    .map((it: any) => {
      const s = String(it.str || "").trim();
      const t = it.transform || [];
      return s ? { s, x: t[4] || 0, y: t[5] || 0 } : null;
    })
    .filter(Boolean) as { s: string; x: number; y: number }[];

  items.sort((a, b) => (Math.abs(b.y - a.y) > 0.01 ? b.y - a.y : a.x - b.x));

  const lines: { y: number; parts: { x: number; s: string }[] }[] = [];
  for (const it of items) {
    const last = lines[lines.length - 1];
    if (!last || Math.abs(it.y - last.y) > T("LINE_Y_TOL")) lines.push({ y: it.y, parts: [{ x: it.x, s: it.s }] });
    else last.parts.push({ x: it.x, s: it.s });
  }

  return lines.map(ln => {
    ln.parts.sort((a, b) => a.x - b.x);
    const tokens = ln.parts.map(p => p.s);
    return { y: ln.y, indentX: Math.min(...ln.parts.map(p => p.x)), tokens, lineText: normalize(tokens.join(" ")) };
  });
}

function parseMarker(tokens: string[]) {
  if (!tokens?.length) return null;
  const t0 = tokens[0];
  if (/^\d+\.$/.test(t0)) return { kind: "NUM" as const, num: Number(t0.replace(".", "")) };
  if (/^\(\d+\)$/.test(t0)) return { kind: "NUM" as const, num: Number(t0.slice(1, -1)) };
  if (/^[A-Za-z]\.$/.test(t0)) return { kind: "ALPHA" as const, ch: t0[0].toUpperCase() };
  if (/^\([A-Za-z]\)$/.test(t0)) return { kind: "ALPHA" as const, ch: t0[1].toUpperCase() };
  if (/^\d+$/.test(t0) && tokens[1] === ".") return { kind: "NUM" as const, num: Number(t0) };
  if (/^[A-Za-z]$/.test(t0) && tokens[1] === ".") return { kind: "ALPHA" as const, ch: t0.toUpperCase() };
  if (t0 === "(" && /^\d+$/.test(tokens[1] || "") && tokens[2] === ")") return { kind: "NUM" as const, num: Number(tokens[1]) };
  if (t0 === "(" && /^[A-Za-z]$/.test(tokens[1] || "") && tokens[2] === ")") return { kind: "ALPHA" as const, ch: String(tokens[1]).toUpperCase() };
  return null;
}

type Marker = { page: number; x: number; y: number; kind: "NUM" | "ALPHA"; num?: number; ch?: string; lineText: string };
type Level = { indentX: number; nextNum: number; nextCh: string };
const newLevel = (indentX: number): Level => ({ indentX, nextNum: 1, nextCh: "A" });

function sortMarkers(ms: Marker[]) {
  ms.sort((a, b) => (a.page !== b.page ? a.page - b.page : Math.abs(b.y - a.y) > 0.01 ? b.y - a.y : a.x - b.x));
  return ms;
}

function findDepth(stack: Level[], x: number) {
  if (!stack.length) return 0;
  if (x > stack[stack.length - 1].indentX + T("INDENT_TOL")) return stack.length;
  while (stack.length && x < stack[stack.length - 1].indentX - T("SAME_TOL")) stack.pop();
  return stack.length ? stack.length - 1 : 0;
}

function validateSequence(markers: Marker[], firstKind: "NUM" | "ALPHA") {
  const stack: Level[] = [];
  const errors: string[] = [];

  for (const m of markers) {
    const depth = findDepth(stack, m.x);
    const expKind = expectedKind(firstKind, depth);

    if (m.kind !== expKind) errors.push(`Page ${m.page}: kind wrong at depth ${depth}. Expected ${expKind} found ${m.kind}. Line: ${m.lineText}`);

    if (depth === stack.length) {
      if (depth > 0 && m.x <= stack[depth - 1].indentX + T("INDENT_TOL"))
        errors.push(`Page ${m.page}: indentation wrong. childX=${m.x} should be > parentX=${stack[depth - 1].indentX}+${T("INDENT_TOL")}. Line: ${m.lineText}`);
      stack.push(newLevel(m.x));
    } else {
      stack[depth].indentX = m.x;
      stack.splice(depth + 1);
    }

    const lvl = stack[depth];
    if (expKind === "NUM") {
      if (typeof m.num !== "number") errors.push(`Page ${m.page}: cannot read number at depth ${depth}. Line: ${m.lineText}`);
      else if (m.num !== lvl.nextNum) { errors.push(`Page ${m.page}: numbering wrong at depth ${depth}. Expected ${lvl.nextNum} found ${m.num}. Line: ${m.lineText}`); lvl.nextNum = m.num + 1; }
      else lvl.nextNum++;
    } else {
      if (!m.ch) errors.push(`Page ${m.page}: cannot read letter at depth ${depth}. Line: ${m.lineText}`);
      else if (m.ch !== lvl.nextCh) { errors.push(`Page ${m.page}: lettering wrong at depth ${depth}. Expected ${lvl.nextCh} found ${m.ch}. Line: ${m.lineText}`); lvl.nextCh = nextLetter(m.ch); }
      else lvl.nextCh = nextLetter(lvl.nextCh);
    }
  }
  return errors;
}

export async function validateOutlineMarkers(pdfPath: string, firstFormat: string) {
  if (!fs.existsSync(pdfPath)) {
    console.log("❌ FAIL (Outline) - PDF not found");
    return { pass: false, markersFound: 0, errorsCount: 0, errorsSample: [] as string[] };
  }

  const firstKind: "NUM" | "ALPHA" = (firstFormat || "").toUpperCase() === "ALPHA" ? "ALPHA" : "NUM";
  const pdf: any = await loadPdfDoc(pdfPath);

  try {
    const markers: Marker[] = [];
    for (let p = 1; p <= pdf.numPages; p++) {
      const page = await pdf.getPage(p);
      for (const ln of await extractLines(page)) {
        const mk = parseMarker(ln.tokens);
        if (mk) markers.push({ page: p, x: ln.indentX, y: ln.y, kind: mk.kind, num: (mk as any).num, ch: (mk as any).ch, lineText: ln.lineText });
      }
    }

    sortMarkers(markers);
    const errors = markers.length ? validateSequence(markers, firstKind) : [];
    const pass = errors.length === 0;

    console.log(pass ? `✅ PASS (Outline) - markers=${markers.length}` : `❌ FAIL (Outline) - markers=${markers.length}, errors=${errors.length}`);
    return { pass, markersFound: markers.length, errorsCount: errors.length, errorsSample: errors.slice(0, 20), firstKind, totalPages: pdf.numPages };
  } finally { await (pdf as any)?.destroy?.(); }
}

/* ===================== 6) Board Copy ===================== */
export async function validateBoardCopy(pdfPath: string, phrase: string, topKeepRatio = 0.75) {
  if (!fs.existsSync(pdfPath)) {
    console.log("❌ FAIL (Board Copy) - PDF not found");
    return { pass: false, pages: [] as number[], phrase };
  }

  const doc: any = await loadPdfDoc(pdfPath, { disableWorker: true });
  const pages: number[] = [];
  const needle = (phrase || "").toLowerCase();

  try {
    for (let p = 1; p <= doc.numPages; p++) {
      const page = await doc.getPage(p);
      const h = page.getViewport({ scale: 1 }).height;
      const yMin = h * topKeepRatio;
      const tc = await page.getTextContent();
      const text = (tc.items || [])
        .filter((it: any) => (it.transform?.[5] ?? 0) >= yMin)
        .map((it: any) => String(it.str || "").trim())
        .join(" ")
        .toLowerCase();

      if (text.includes(needle)) pages.push(p);
    }
  } finally { await (doc as any)?.destroy?.(); }

  const pass = pages.length > 0;
  console.log(pass ? "✅ PASS (Board Copy)" : "❌ FAIL (Board Copy)");
  return { pass, pages, phrase };
}

/* ===================== 7) Search ===================== */
export async function searchPdfText(pdfPath: string, query: string) {
  const clean = (s: any) => String(s || "").replace(/\s+/g, " ").trim();

  const buildLines = (items: any[], yTol = 2) => {
    const arr = (items || [])
      .map((it: any) => ({ s: clean(it.str), x: it.transform?.[4], y: it.transform?.[5] }))
      .filter((t: any) => t.s && typeof t.x === "number" && typeof t.y === "number");

    const map = new Map<number, any[]>();
    for (const t of arr) {
      const yKey = Math.round(t.y / yTol) * yTol;
      if (!map.has(yKey)) map.set(yKey, []);
      map.get(yKey)!.push(t);
    }

    return [...map.keys()]
      .sort((a, b) => b - a)
      .map(y => map.get(y)!.sort((a, b) => a.x - b.x).map(z => z.s).join(" ").replace(/\s+/g, " ").trim());
  };

  const exactHits = (lines: string[], q: string) => {
    const L = lines.map(clean);
    const starts: number[] = [];
    let big = "";

    for (let i = 0; i < L.length; i++) { starts[i] = big.length; big += (i ? " " : "") + L[i]; }

    const bigLow = big.toLowerCase(), qLow = q.toLowerCase();
    const hits: { from: number; to: number }[] = [];

    for (let pos = 0;;) {
      const k = bigLow.indexOf(qLow, pos);
      if (k < 0) break;
      const end = k + qLow.length - 1;

      let from = 1, to = 1;
      for (let i = 0; i < starts.length; i++) if (starts[i] <= k) from = i + 1;
      for (let i = 0; i < starts.length; i++) if (starts[i] <= end) to = i + 1;

      hits.push({ from, to });
      pos = k + qLow.length;
    }
    return hits;
  };

  if (!fs.existsSync(pdfPath)) {
    console.log("❌ FAIL (Search) - PDF not found");
    return { pass: false, count: 0, matches: [] as any[], query };
  }

  const q = clean(query);
  if (!q) {
    console.log("❌ FAIL (Search) - Empty query");
    return { pass: false, count: 0, matches: [] as any[], query };
  }

  const pdf: any = await loadPdfDoc(pdfPath, { disableWorker: true });
  const matches: { page: number; from: number; to: number }[] = [];

  try {
    for (let p = 1; p <= pdf.numPages; p++) {
      const page = await pdf.getPage(p);
      const tc = await page.getTextContent({ disableCombineTextItems: false });
      const hits = exactHits(buildLines(tc.items || []), q);
      hits.forEach(h => matches.push({ page: p, from: h.from, to: h.to }));
    }
  } finally { await (pdf as any)?.destroy?.(); }

  const pass = matches.length > 0;
  console.log(pass ? `✅ PASS (Search) - ${matches.length} match(es)` : "❌ FAIL (Search) - No matches");
  return { pass, count: matches.length, matches, query };
}

/* ===================== 8) Export Linked Figures (PNG output) ===================== */
export async function exportLinkedFigures(
  pdfPath: string,
  outDir: string,
  scale = 3,
  headerPct = 0.15,
  footerPct = 0.15,
  tessDataPath = "./tessdata"
) {
  if (!fs.existsSync(pdfPath)) {
    console.log("❌ FAIL (Export Figures) - PDF not found");
    return { pass: false, pages: [] as number[], titles: [] as string[], saved: [] as string[] };
  }
  if (!fs.existsSync(path.join(tessDataPath, "eng.traineddata"))) {
    console.log("❌ FAIL (Export Figures) - Missing eng.traineddata");
    return { pass: false, pages: [], titles: [], saved: [] as string[] };
  }

  ensureDir(outDir);

  const clean = (s: any) => String(s || "").replace(/\s+/g, " ").trim();
  const safe = (s: string) => clean(s).replace(/[\\/:*?"<>|]/g, "_").slice(0, 150);
  const uniq = (name: string) => {
    let f = path.join(outDir, name + ".png"), i = 2;
    while (fs.existsSync(f)) f = path.join(outDir, `${name}_${i++}.png`);
    return f;
  };
  const afterFigure = (s: string) => {
    s = clean(s).replace(/^_+|_+$/g, "");
    const m = s.match(/Figure\s*\d+\s*(.*)$/i);
    return m ? clean(m[1]) : "";
  };

  const buildLines = (items: any[], yTol = 2) => {
    const arr = (items || [])
      .map((it: any) => ({ s: clean(it.str), x: it.transform?.[4], y: it.transform?.[5] }))
      .filter((t: any) => t.s && typeof t.x === "number" && typeof t.y === "number");
    const map = new Map<number, any[]>();
    for (const t of arr) {
      const yKey = Math.round(t.y / yTol) * yTol;
      if (!map.has(yKey)) map.set(yKey, []);
      map.get(yKey)!.push(t);
    }
    return [...map.keys()]
      .sort((a, b) => b - a)
      .map(y => map.get(y)!.sort((a, b) => a.x - b.x).map(z => z.s).join(" ").replace(/\s+/g, " ").trim());
  };

  const getTitleFromDestPage = async (page: any) => {
    const tc = await page.getTextContent({ disableCombineTextItems: false });
    for (const line of buildLines(tc.items || [])) {
      if (!/^_?\s*Figure\s*\d+/i.test(line)) continue;
      const t = afterFigure(line);
      if (t) return t;
    }
    return "";
  };

  const pdf: any = await loadPdfDoc(pdfPath, { verbosity: 0 });
  const destToLabel = new Map<number, string>();
  const titles: string[] = [];
  const saved: string[] = [];
  const worker = await createWorker("eng", undefined, { langPath: tessDataPath, gzip: false, logger: () => {} });

  try {
    for (let p = 1; p <= pdf.numPages; p++) {
      const page = await pdf.getPage(p);
      const annots = await page.getAnnotations();
      const links = (annots || []).filter((a: any) => a.subtype === "Link" && a.dest && !(a.url || a.unsafeUrl) && a.rect);
      if (!links.length) continue;

      const { canvas, viewport } = await renderPageToCanvas(page, 4);
      for (const a of links) {
        const { x, y, w, h } = computeRect(viewport, a.rect, canvas);
        if (w < 2 || h < 2) continue;

        const label = await ocrCrop(worker, canvas, x, y, w, h);
        if (!/Figure\s*\d+/i.test(label)) continue;

        const dp = await resolveDestPage(pdf, a.dest);
        if (!dp) continue;

        const old = destToLabel.get(dp) || "";
        if (label.length > old.length) destToLabel.set(dp, label);
      }
    }

    const destPages = [...destToLabel.keys()].sort((a, b) => a - b);
    if (!destPages.length) {
      console.log("✅ PASS (Export Figures) - No figure links");
      return { pass: true, pages: [], titles: [], saved: [] };
    }

    const pages: number[] = [];
    for (const pageNo of destPages) {
      const page = await pdf.getPage(pageNo);

      let title = await getTitleFromDestPage(page);
      if (!title) title = afterFigure(destToLabel.get(pageNo) || "");
      if (!title) title = `Figure_Page_${pageNo}`;

      pages.push(pageNo);
      titles.push(title);

      const { canvas } = await renderPageToCanvas(page, scale);
      const W = canvas.width, H = canvas.height;

      const cutTop = Math.floor(H * headerPct);
      const cutBot = Math.floor(H * footerPct);
      const newH = Math.max(1, H - cutTop - cutBot);

      const crop = createCanvas(W, newH);
      crop.getContext("2d").drawImage(canvas as any, 0, cutTop, W, newH, 0, 0, W, newH);

      const file = uniq(safe(title));
      fs.writeFileSync(file, crop.toBuffer("image/png"));
      saved.push(file);
    }

    console.log(`✅ PASS (Export Figures) - Exported ${saved.length} PNG(s)`);
    return { pass: true, pages, titles, saved };
  } finally { await worker.terminate(); await (pdf as any)?.destroy?.(); }
}

/* ===================== 9) Figure Compare (diff PNG output) ===================== */
const listPng = (dir: string) => (fs.existsSync(dir) ? fs.readdirSync(dir).filter(f => f.toLowerCase().endsWith(".png")) : []);
const readPng = (file: string, PNG: any) => PNG.sync.read(fs.readFileSync(file));

export async function compareFigureImages(expectedDir: string, actualDir: string, diffDir: string) {
  ensureDir(diffDir);

  const pm = _req("pixelmatch");
  const pixelmatch = pm.default || pm;
  const { PNG } = _req("pngjs");

  const exp = listPng(expectedDir), act = listPng(actualDir);
  if (!exp.length) {
    console.log("❌ FAIL (Figure Compare) - No expected PNGs");
    return { pass: false, compared: 0, failed: 1, added: [] as string[], removed: [] as string[], failures: [] as any[] };
  }

  const expSet = new Set(exp), actSet = new Set(act);
  const removed = exp.filter(n => !actSet.has(n));
  const added = act.filter(n => !expSet.has(n));
  const common = exp.filter(n => actSet.has(n));

  let compared = 0, failed = 0;
  const failures: Array<{ name: string; reason: string; diffFile?: string }> = [];

  for (const name of common) {
    const e = readPng(path.join(expectedDir, name), PNG);
    const a = readPng(path.join(actualDir, name), PNG);
    compared++;

    if (e.width !== a.width || e.height !== a.height) {
      failed++;
      failures.push({ name, reason: `size mismatch exp=${e.width}x${e.height} act=${a.width}x${a.height}` });
      continue;
    }

    const d = new PNG({ width: e.width, height: e.height });
    const diffPixels = pixelmatch(e.data, a.data, d.data, e.width, e.height, { threshold: 0, includeAA: true });

    const diffFile = path.join(diffDir, name.replace(/\.png$/i, "_diff.png"));
    fs.writeFileSync(diffFile, PNG.sync.write(d));

    if (diffPixels > 0) { failed++; failures.push({ name, reason: `diffPixels=${diffPixels}`, diffFile }); }
  }

  const pass = failed === 0 && !added.length && !removed.length;
  console.log(pass ? `✅ PASS (Figure Compare) - Compared=${compared}` : `❌ FAIL (Figure Compare) - Failed=${failed}, Added=${added.length}, Removed=${removed.length}`);
  return { pass, compared, failed, added, removed, failures };
}

/* ===================== 10) Margins ===================== */
export type MarginOpts = { leftMm?: number; rightMm?: number; dpi?: number; topExcludeMm?: number; bottomExcludeMm?: number; adaptive?: boolean; delta?: number; fixedThr?: number; failRatio?: number };

const mmToPx = (mm: number, dpi: number) => Math.round((mm / 25.4) * dpi);
const lum = (r: number, g: number, b: number) => 0.2126 * r + 0.7152 * g + 0.0722 * b;

function adaptiveThr(img: CanvasImageData, width: number, region: any, delta: number) {
  const d = img.data, samples: number[] = [];
  for (let y = region.y0; y < region.y1; y += 3) for (let x = region.x0; x < region.x1; x += 3) {
    const i = (y * width + x) * 4;
    if (d[i + 3] < 10) continue;
    samples.push(lum(d[i], d[i + 1], d[i + 2]));
  }
  if (!samples.length) return 245;
  samples.sort((a, b) => a - b);
  return Math.max(0, Math.min(255, samples[Math.floor(samples.length * 0.95)] - delta));
}

function inkRatio(img: CanvasImageData, width: number, region: any, thr: number) {
  const d = img.data;
  const w = region.x1 - region.x0, h = region.y1 - region.y0;
  const total = w * h;
  if (total <= 0) return 0;

  let ink = 0;
  for (let y = region.y0; y < region.y1; y++) for (let x = region.x0; x < region.x1; x++) {
    const i = (y * width + x) * 4;
    if (d[i + 3] < 10) continue;
    if (lum(d[i], d[i + 1], d[i + 2]) < thr) ink++;
  }
  return ink / total;
}

async function renderPageAtDpi(page: any, dpi: number) {
  const scale = dpi / 72;
  const vp = page.getViewport({ scale });
  const canvas = createCanvas(Math.floor(vp.width), Math.floor(vp.height));
  const ctx = canvas.getContext("2d");
  await page.render({ canvasContext: ctx, viewport: vp }).promise;
  return { ctx, width: canvas.width, height: canvas.height };
}

function marginRegions(width: number, height: number, dpi: number, leftMm: number, rightMm: number, topMm: number, bottomMm: number) {
  const leftPx = mmToPx(leftMm, dpi);
  const rightPx = mmToPx(rightMm, dpi);
  const y0 = mmToPx(topMm, dpi);
  const y1 = height - mmToPx(bottomMm, dpi);

  return {
    left: { x0: 0, x1: Math.min(leftPx, width), y0, y1 },
    right: { x0: Math.max(0, width - rightPx), x1: width, y0, y1 },
  };
}

export async function validateMargins(pdfPath: string, o: MarginOpts = {}) {
  const opts = {
    leftMm: o.leftMm ?? 10,
    rightMm: o.rightMm ?? 8,
    dpi: o.dpi ?? 200,
    topExcludeMm: o.topExcludeMm ?? 0,
    bottomExcludeMm: o.bottomExcludeMm ?? 0,
    adaptive: o.adaptive ?? true,
    delta: o.delta ?? 12,
    fixedThr: o.fixedThr ?? 245,
    failRatio: o.failRatio ?? 0.005,
  };

  if (!fs.existsSync(pdfPath)) {
    console.log("❌ FAIL (Margins) - PDF not found");
    return { pass: false, failedPages: [] as number[], failures: [] as any[] };
  }

  const pdf: any = await loadPdfDoc(pdfPath, { disableWorker: true });
  const failures: Array<{ page: number; leftRatio: number; rightRatio: number }> = [];

  try {
    for (let p = 1; p <= pdf.numPages; p++) {
      const page = await pdf.getPage(p);
      const { ctx, width, height } = await renderPageAtDpi(page, opts.dpi);
      const img = ctx.getImageData(0, 0, width, height);

      const { left, right } = marginRegions(width, height, opts.dpi, opts.leftMm, opts.rightMm, opts.topExcludeMm, opts.bottomExcludeMm);
      const lThr = opts.adaptive ? adaptiveThr(img, width, left, opts.delta) : opts.fixedThr;
      const rThr = opts.adaptive ? adaptiveThr(img, width, right, opts.delta) : opts.fixedThr;

      const lRatio = inkRatio(img, width, left, lThr);
      const rRatio = inkRatio(img, width, right, rThr);

      if (lRatio >= opts.failRatio || rRatio >= opts.failRatio) failures.push({ page: p, leftRatio: lRatio, rightRatio: rRatio });
    }
  } finally { await (pdf as any)?.destroy?.(); }

  const failedPages = failures.map(f => f.page);
  const pass = failures.length === 0;

  console.log(pass ? "✅ PASS (Margins)" : `❌ FAIL (Margins) - Failed pages: ${failedPages.join(", ")}`);
  return { pass, failedPages, failures, opts };
}

/* ===================== 11) Effectivity (SOFT) ===================== */
const efClamp = (v: number, a: number, b: number) => Math.max(a, Math.min(b, v));
const efNearW = (r: number, g: number, b: number) => r > 245 && g > 245 && b > 245;
const efNearB = (r: number, g: number, b: number) => r < 25 && g < 25 && b < 25;

function efHsv(r: number, g: number, b: number) {
  const rr = r / 255, gg = g / 255, bb = b / 255;
  const mx = Math.max(rr, gg, bb), mn = Math.min(rr, gg, bb), d = mx - mn;
  let h = 0;
  if (d) {
    if (mx === rr) h = ((gg - bb) / d) % 6;
    else if (mx === gg) h = (bb - rr) / d + 2;
    else h = (rr - gg) / d + 4;
    h *= 60;
    if (h < 0) h += 360;
  }
  return { h, s: mx ? d / mx : 0, v: mx };
}

const efPink = (r: number, g: number, b: number) => {
  const { h, s, v } = efHsv(r, g, b);
  return h >= 285 && h <= 355 && s >= 0.2 && v >= 0.25;
};

function efBuildMap(items: any[]) {
  let full = "";
  const map: number[] = [];
  for (let i = 0; i < items.length; i++) {
    const s = items[i]?.str ?? "";
    for (let k = 0; k < s.length; k++) map.push(i);
    full += s;
    map.push(i);
    full += " ";
  }
  return { full, map };
}

function efIdxsFor(map: number[], a: number, b: number) {
  const set = new Set<number>();
  const s = efClamp(a, 0, map.length - 1), e = efClamp(b, 0, map.length);
  for (let i = s; i < e; i++) set.add(map[i]);
  return [...set].sort((x, y) => x - y);
}

function efBBox(viewport: any, items: any[], idxs: number[]) {
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity;
  for (const id of idxs) {
    const it = items[id];
    if (!it?.transform) continue;
    const t = (pdfjs as any).Util.transform(viewport.transform, it.transform) as number[];
    const x = t[4], y = t[5];
    const h = Math.hypot(t[1], t[3]) || Math.hypot(t[2], t[3]) || 10;
    const w = Math.abs(it.width ?? 0);
    minX = Math.min(minX, x);
    minY = Math.min(minY, y - h);
    maxX = Math.max(maxX, x + w);
    maxY = Math.max(maxY, y);
  }
  return isFinite(minX) ? { x0: minX, y0: minY, x1: maxX, y1: maxY } : null;
}

const efExpand = (b: any, m: number, W: number, H: number) => ({
  x0: efClamp(b.x0 - m, 0, W),
  y0: efClamp(b.y0 - m, 0, H),
  x1: efClamp(b.x1 + m, 0, W),
  y1: efClamp(b.y1 + m, 0, H),
});

function efTightenPink(ctx: any, b: any, mode: "TEXT" | "HIGHLIGHT") {
  const W = ctx.canvas.width, H = ctx.canvas.height;
  const x0 = Math.floor(efClamp(b.x0, 0, W)), y0 = Math.floor(efClamp(b.y0, 0, H));
  const x1 = Math.ceil(efClamp(b.x1, 0, W)), y1 = Math.ceil(efClamp(b.y1, 0, H));
  const w = x1 - x0, h = y1 - y0;
  if (w <= 1 || h <= 1) return null;

  const data = ctx.getImageData(x0, y0, w, h).data;
  let minX = Infinity, minY = Infinity, maxX = -Infinity, maxY = -Infinity, cnt = 0;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], bb = data[i + 2], a = data[i + 3];
    if (a < 20) continue;
    if (mode === "TEXT") { if (efNearW(r, g, bb)) continue; }
    else { if (efNearB(r, g, bb) || efNearW(r, g, bb)) continue; }
    if (!efPink(r, g, bb)) continue;

    const p = i / 4, px = p % w, py = Math.floor(p / w);
    minX = Math.min(minX, px); minY = Math.min(minY, py);
    maxX = Math.max(maxX, px); maxY = Math.max(maxY, py);
    cnt++;
  }

  if (cnt < 10 || !isFinite(minX)) return null;
  const pad = 2;
  return { x0: efClamp(x0 + minX - pad, 0, W), y0: efClamp(y0 + minY - pad, 0, H), x1: efClamp(x0 + maxX + pad, 0, W), y1: efClamp(y0 + maxY + pad, 0, H) };
}

function efCheckPink(ctx: any, b: any, mode: "TEXT" | "HIGHLIGHT") {
  const W = ctx.canvas.width, H = ctx.canvas.height;
  const x0 = Math.floor(efClamp(b.x0, 0, W)), y0 = Math.floor(efClamp(b.y0, 0, H));
  const x1 = Math.ceil(efClamp(b.x1, 0, W)), y1 = Math.ceil(efClamp(b.y1, 0, H));
  const w = x1 - x0, h = y1 - y0;
  if (w <= 1 || h <= 1) return { ok: false, reason: "Empty bbox", sampled: 0 };

  const data = ctx.getImageData(x0, y0, w, h).data;
  let sampled = 0, pink = 0;

  for (let i = 0; i < data.length; i += 4) {
    const r = data[i], g = data[i + 1], bb = data[i + 2], a = data[i + 3];
    if (a < 20) continue;
    if (mode === "TEXT") { if (efNearW(r, g, bb)) continue; }
    else { if (efNearB(r, g, bb) || efNearW(r, g, bb)) continue; }
    sampled++;
    if (efPink(r, g, bb)) pink++;
  }

  if (sampled < 40) return { ok: false, reason: "Too few pixels", sampled };
  return { ok: true, sampled, pinkishRatio: pink / sampled };
}

async function efScanPage(page: any, pageNo: number, scale: number, margin: number, mode: "TEXT" | "HIGHLIGHT") {
  const RE = /\(\s*(EFFECTIVITY\s+(GROUP|TAILS)\s*:[^)]+)\)/gi;

  const { canvas, ctx, viewport } = await renderPageToCanvas(page, scale);
  const tc = await page.getTextContent({ normalizeWhitespace: true });
  const items = tc.items as any[];
  const { full, map } = efBuildMap(items);

  const hits: any[] = [], bad: any[] = [];
  RE.lastIndex = 0;

  for (let m: RegExpExecArray | null; (m = RE.exec(full));) {
    const text = (m[1] || "").trim();
    const kind = (String(m[2] || "").toUpperCase() === "GROUP" ? "GROUP" : "TAILS") as "GROUP" | "TAILS";

    const idxs = efIdxsFor(map, m.index, m.index + m[0].length);
    const raw = efBBox(viewport, items, idxs);

    const entry: any = { page: pageNo, kind, text, bbox: null, color: null };
    if (!raw) { entry.color = { ok: false, reason: "No bbox", sampled: 0 }; hits.push(entry); bad.push(entry); continue; }

    const rough = efExpand(raw, margin, canvas.width, canvas.height);
    const tight = efTightenPink(ctx, rough, mode);
    entry.bbox = tight ?? rough;
    entry.color = efCheckPink(ctx, entry.bbox, mode);

    hits.push(entry);
    if (!entry.color.ok) bad.push(entry);
  }

  return { hits, bad };
}

export async function validateEffectivitySoft(pdfPath: string, scale = 2.5, margin = 6, mode: "TEXT" | "HIGHLIGHT" = "TEXT") {
  if (!fs.existsSync(pdfPath)) {
    console.log("❌ FAIL (Effectivity) - PDF not found");
    return { pass: false, groupHits: 0, tailsHits: 0, bad: 0 };
  }

  const pdf: any = await loadPdfDoc(pdfPath, { disableWorker: true, verbosity: 0 });
  const hits: any[] = [], bad: any[] = [];

  try {
    for (let p = 1; p <= pdf.numPages; p++) {
      const page = await pdf.getPage(p);
      const res = await efScanPage(page, p, scale, margin, mode);
      hits.push(...res.hits);
      bad.push(...res.bad);
    }
  } finally { await (pdf as any)?.destroy?.(); }

  const groupHits = hits.filter(h => h.kind === "GROUP").length;
  const tailsHits = hits.filter(h => h.kind === "TAILS").length;

  const pass = groupHits > 0 && tailsHits > 0 && bad.length === 0;
  console.log(pass ? "✅ PASS (Effectivity)" : `❌ FAIL (Effectivity) - GROUP=${groupHits}, TAILS=${tailsHits}, bad=${bad.length}`);

  return { pass, groupHits, tailsHits, bad: bad.length, presencePass: groupHits > 0 && tailsHits > 0, colorPass: bad.length === 0 };
}