import { Locator, Page, expect } from '@playwright/test';
import kcslocator from '../Locators/pageLocator.json';
import * as dmLoc from '../Locators/pageLocator.json';
import * as testdata from '../test-data/sample-test.json';

export default class helper{

    constructor(private page: Page) {}

    async goto(url: string): Promise<void> {
        await this.page.goto(url, {
            waitUntil: 'domcontentloaded',
        });
    }

    async setValue(locator: string, text: string): Promise<void> {
        try {
            const element = this.page.locator(locator);
            await element.waitFor({
                state: 'visible',
            });
            await element.fill(text);
            console.log(`Value set on locatorValue ${locator} and value ${text}`);
        } catch (e) {
            throw new Error(`Value not set in Locator Type ${locator} and text ${text}  and the error message is ${e}`);
        }
    }

    async clickbtn(locatorValue: string): Promise<void> {
        const element = this.page.locator(locatorValue);
        try {
            await this.page.waitForSelector(locatorValue, { timeout: 5000 });
            await element.click();
            console.log(`Element is Clicked as expected with LocatorValue:${locatorValue}`);
        } catch (error) {
            throw new Error(
                `Element is Not performed click LocatorValue:${locatorValue} and the error message is ${error}`,
            );
        }
    }
    async getAllMatOptionDropdown(selectLocator: string): Promise<string[]> {
        try {

            const selectDropDown = this.page.locator(selectLocator);
            await selectDropDown.waitFor();

            if (await selectDropDown.isDisabled()) {
                console.log(`Dropdown is disabled and cannot be clicked`);
                return [];
            }

            // Click to open the dropdown
            await this.clickbtn(selectLocator);

            // Get all dropdown options
            await this.page.waitForSelector('mat-option[label="select"]', { state: 'visible' });
            const dropdownOptions = this.page.locator('mat-option[label="select"]');
            const options = await dropdownOptions.allTextContents();

            if (options.length === 0) {
                console.log('No options available in the dropdown');
                return [];
            }

            // Select the first option and click OK
            // await dropdownOptions.first().click();
            const randomIndex = Math.floor(Math.random() * options.length);
            console.log(`${randomIndex}   randomIndex`);
            const randomOption = dropdownOptions.nth(randomIndex);
            const randomOptionText = options[randomIndex].trim();

            console.log(`Selecting random CSDB: ${randomOptionText}`);
            await randomOption.click();
            await this.page.locator(kcslocator.home[0].ok).click();

            // Return the trimmed options
            return options.map((option) => option.trim());
        } catch (error) {
            throw new Error(`An error occurred while selecting dropdown "${selectLocator}": ${error}`);
        }
    }

    async clickdm(locatorValue: string): Promise<Page> {
        const cardLocator = this.page.locator('mat-card:has-text("Data Manager")');
        const openButton = cardLocator.locator(locatorValue);
        let dmpage: Page;
        try {
            [dmpage] = await Promise.all([
            this.page.waitForEvent('popup'),
            openButton.click(),
        ]);
        if (dmpage) {
            await dmpage.waitForLoadState('networkidle');
            console.log(`Element is Clicked as expected with LocatorValue:${locatorValue}`);
        } else {
             throw new Error('Click did not result in a new popup page.');
        }
        } 
        catch (error) {
            throw new Error(
                `Element is Not performed click LocatorValue:${locatorValue} and the error message is ${error}`,
            );
        }
        
         return dmpage;
    }



    async checkTable(tableLocatorString: string): Promise<boolean> {
        try {        
            const dataRowLocator = this.page.locator(tableLocatorString);

            const rowCount = await dataRowLocator.count();

            if (rowCount > 0) {
                console.log(`Table Check: Found ${rowCount} rows.`);
                return true;
            } else {
                console.log('Table Check: No data rows found.');
                return false;
            }

        } catch (error) {
            console.error(`Table Check FAILED: Error encountered while verifying table: ${error}`);
            return false;
        }
    }
    async optselector(locate:string,text:string):Promise<void>{
        try{
            const selectDropDown = this.page.locator(locate);
            await selectDropDown.waitFor();
            await selectDropDown.selectOption({label:text});
            console.log(`Selected option "${text}" in dropdown located by "${locate}".`);
        }
        catch (error) {
        throw new Error(`FAILED to select option "${text}" in dropdown located by "${locate}". ` + `Details: ${error}`
        );
        }
    }

    async checkbox(locate:string,text:boolean):Promise<void>{
        try {
        const checkboxLocator = this.page.locator(locate);
        await checkboxLocator.waitFor({ state: 'visible', timeout: 5000 });

        if (text) {
            await checkboxLocator.check();
            await expect(checkboxLocator).toBeChecked();
            console.log(`Checkbox located by "${locate}" was successfully CHECKED and verified.`);
            
        } else {
            await checkboxLocator.uncheck();
            await expect(checkboxLocator).not.toBeChecked();
            console.log(`Checkbox located by "${locate}" was successfully UNCHECKED and verified.`);
        }      
    }catch (error) {
        const action = text ? 'CHECKING' : 'UNCHECKING';
        
        throw new Error(`FAILED during ${action} of checkbox located by "${locate}". ` +`Details: ${ error}`);
    }
    }

    async uploadfile(locate: string, path: string): Promise<void> {
    
    try {
        const fileInputLocator = this.page.locator(locate);
        await fileInputLocator.setInputFiles(path);
        
        console.log(`Successfully uploaded file from path: "${path}" using locator: "${locate}".`);
        
    } catch (error) {
        throw new Error(`FAILED to upload file "${path}" using locator "${locate}" `);
    }
    }
    async selectprodiv(name: string,btn:string): Promise<void>{
        try {
        const progressdiv = this.page.locator(kcslocator.dm[0].progressdiv).filter({ hasText: name });
        const button: Locator = progressdiv.locator(kcslocator.dm[0].progressok,{hasText:btn});
        await expect(button).toBeVisible({ timeout: 300000 });

        await button.click();
        
        console.log(`Successfully clicked the "${btn}" button in the progress section named: "${name}".`);
        
    } catch (error) {
        const errorMessage = `FAILED to interact with the "${btn}" button in the section "${name}".`;
        
        throw new Error(`${errorMessage} Locator: "${kcslocator.dm[0].progressdiv}" with text filter "${name}". ` +`Details: ${ error}`);
    }

    }
    async showresult(): Promise<string> {
        const result: Locator = this.page.locator(kcslocator.dm[0].statusbar);
        
        try {
            const content = await result.textContent();

            return content?.trim() || '';

        } catch (error) {
            throw new Error(`Failed to retrieve text from status bar locator: ${kcslocator.dm[0].statusbar}. Details: ${error}`);
        }
    }
    async printreport(locate: string): Promise<void> {
    
        const report: Locator = this.page.locator(locate);

        try {
            await expect(report.first()).toBeVisible({ timeout: 20000 });
            const reportNames = await report.allTextContents();
            const zeroIssuesList: string[] = [];
            const withIssuesList: string[] = [];

            console.log("--- Report Summary ---");

            if (reportNames.length === 0) {
                console.log("No report tabs were found, even after waiting.");
            } else {
                for (const name of reportNames) {
                    const trimmedName = name.trim();
                    const issueMatch = trimmedName.match(/-\s*(\d+)\s*issues/i);
                    if (issueMatch) {
                        const issueCount = parseInt(issueMatch[1], 10);
                        if (issueCount === 0) {
                        zeroIssuesList.push(trimmedName);
                    } else {
                        withIssuesList.push(trimmedName);
                    }
                }else if (trimmedName.toLowerCase().includes('issues')) {
                    withIssuesList.push(trimmedName);
                }
                }
            }
            console.log("Without Issues");
            zeroIssuesList.forEach(item => console.log(`   - ${item}`));
            console.log("With Issues");
            withIssuesList.forEach(item => console.log(`   - ${item}`));
            console.log("----------------------");

        } catch (error) {
            throw new Error(`FAILED to retrieve report data using locator: "${locate}". ` + `This may be due to a timeout (20s) or the element not becoming visible. ` +`Details: ${error}`);
        }
    }
    async contimport(btn: string): Promise<void> {
        try {
            const button = this.page.locator(btn,{ hasText: 'Continue With Import' });
            await button.click();
            console.log(`Successfully clicked the continuation button: "${btn}"`);
            await this.pollImportStatusAndClickOK(testdata.s10000d41[0]['Revision Name']);
            

        } catch (error) {
            throw new Error(`FAILED during import continuation process. ` +`Details: ${error}`);
        }
    }
    async stopimport(btn:string):Promise<void>{
        try {
            const button = this.page.locator(btn,{hasText : 'Stop Import'});
            await button.click();
            console.log(`Successfully clicked the continuation button: "${btn}"`);
            await this.pollImportStatusAndClickOK(testdata.s10000d41[0]['Revision Name']);
            

        } catch (error) {
            throw new Error(`FAILED during import continuation process. ` +`Details: ${error}`);
        }      
    }

    async pollImportStatusAndClickOK(revisionName: string): Promise<void> {
        const statusLocator = this.page.locator(dmLoc.dm[0].statusbar);
        const progressdiv = this.page.locator(dmLoc.dm[0].progressdiv).filter({ hasText: revisionName });
        const progressbar = progressdiv.getByRole('progressbar');
        const pollIntervalMs = 5000;

        let currentStatus = (await statusLocator.textContent())?.trim();
        
        let progressbarText = (await progressbar.textContent())?.trim();
        console.log(`Monitoring progress for ${revisionName}. Initial progress bar text: ${progressbarText}`);

        try {
            while (true) {
                await this.page.waitForTimeout(pollIntervalMs);

                const newStatus = (await statusLocator.textContent())?.trim();

                if (newStatus && newStatus !== currentStatus) {
                    currentStatus = newStatus;
                    console.log(`Status Updated: ${currentStatus}`);
                }

                if (currentStatus === "Import Completed" || currentStatus === "Import Failed") {
                    console.log(`Monitoring complete with final status: ${currentStatus}`);
                    break; 
                }
            }

        } catch (error) {
            throw new Error(`Error during status polling for ${revisionName}. Details: ${error}`);
        }
        if (currentStatus === "Import Completed") {
            try {
                const btnok: Locator = progressdiv.locator(dmLoc.dm[0].progressok, { hasText: 'OK' });

                await expect(btnok).toBeVisible({ timeout: 10000 }); 
                await btnok.click();

            } catch (error) {
                throw new Error(`Failed to click 'OK' button after successful import for ${revisionName}. Details: ${error}`);
            }
        } else if (currentStatus === "Import Failed") {
            console.log(`Import failed for ${revisionName}. 'OK' click skipped.`);
        }

        console.log(`Final Status : ${currentStatus}`);
    }
    
}