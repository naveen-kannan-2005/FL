import { test, expect, Page } from '@playwright/test';
import * as homeLoc from '../Locators/pageLocator.json';
import { LoginPage } from '../Pages/login';
 import { HomePage } from '../Pages/home';
import { Data } from '../Pages/dm';

test('Automate', async ({ page }) => {
   
    const loginPage = new LoginPage(page);
    const homePage = new HomePage(page);
    let dmPage: Page;
 
    try{
        await loginPage.login(homeLoc.login[0].user,homeLoc.login[0].pass);
    }
    catch(error) {
    console.error(`Login FAILED for user: ${homeLoc.login[0].user}. Details: An unknown error occurred: ${error}`);
    }
    try {
        dmPage = await homePage.clickdm();
        
        console.log(`Successfully opened the Data Manager page.`);
        
    } catch (error) {
        console.error(`ACTION ERROR: Failed to click or open the DM page.`);
        console.error(`Details: ${error}`);
        throw error;
    }
    
    const dm = new Data(dmPage);
    

    try {
        await dm.selectpath();
        console.log(`Successfully completed path selection.`);

    } catch (error) {
        console.error(`ACTION ERROR: Failed during path selection (dm.selectpath()).`);
        console.error(`Details: ${error}`);
        throw error;
    }
    try {
        await dm.importpack();
        console.log(`Successfully imported package files (dm.importpack()).`);
        
    } catch (error) {
        console.error(`ACTION ERROR: Failed during package import (dm.importpack()).`);
        console.error(`Details: ${error}`);
        throw error;
    }
    try {
        await dm.contimport(); 
        console.log(`Successfully completed the import process and closed the progress window (dm.contimport()).`);

    } catch (error) {
        console.error(`ACTION ERROR: Failed during the import continuation/polling process (dm.contimport()).`);
        console.error(`Details: ${error}`);
        throw error;
    }
    await page.pause();
    
    
});