import { Page, Locator, expect } from '@playwright/test';
import * as homeLoc from '../Locators/pageLocator.json';
import helper from "../utils/helper";

export class HomePage{
    private base: helper;
    
    constructor(private page: Page) {
        this.base = new helper(page);
    }

    async clickdm(): Promise<Page> {
        await this.base.getAllMatOptionDropdown(homeLoc.home[0].drop,);
        await this.base.clickbtn(homeLoc.home[0].app);
        const dmPage = await this.base.clickdm(homeLoc.home[0].open);
        return dmPage;
    }


}