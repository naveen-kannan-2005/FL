import { Page, Locator } from '@playwright/test';
import * as homeLoc from '../Locators/pageLocator.json';
import helper from "../utils/helper";

export class LoginPage {
    private base: helper;

    constructor(private page: Page) {
        this.base = new helper(page);
    }

    async login(username: string, pass: string): Promise<void>{
        for (const user of homeLoc.login){
            await this.base.goto(user.url);
            await this.base.setValue(user.name, username);
            await this.base.setValue(user.password, pass);
            await this.base.clickbtn(user.loginBtn);
        }
    }
    
    
}