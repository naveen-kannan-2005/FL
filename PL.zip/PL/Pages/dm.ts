import { Page, Locator , expect } from '@playwright/test';
import * as dmLoc from '../Locators/pageLocator.json';
import * as testdata from '../test-data/sample-test.json';
import helper from "../utils/helper";

export class Data{
    private base: helper;
    
    constructor(private page: Page) {
        this.base = new helper(page);
    }
    async selectpath(): Promise<void>{
        await this.base.clickbtn(dmLoc.dm[0].import);
        await this.base.clickbtn(dmLoc.dm[0].kc7);
        await this.base.clickbtn(dmLoc.dm[0].sample);
        await this.base.clickbtn(dmLoc.dm[0].testsample);
        await this.page.waitForLoadState('networkidle');
        await this.page.waitForTimeout(2000);
    }

    async importpack(): Promise<void>{
        if (await this.base.checkTable(dmLoc.dm[0].table)) {
            await this.base.optselector(dmLoc.dm[0]['Builder-Name'],testdata.s10000d41[0]['Builder Name']);
            await this.base.setValue(dmLoc.dm[0].Description,testdata.s10000d41[0].Description);
            await this.base.clickbtn(dmLoc.dm[0].add);
            await this.base.setValue(dmLoc.dm[0]['Revision-Name'],testdata.s10000d41[0]['Revision Name']);
            await this.base.optselector(dmLoc.dm[0]['Revision-Type'],testdata.s10000d41[0]['Revision Type']);
            await this.base.checkbox(dmLoc.dm[0]['Run OEM BREX'],testdata.s10000d41[0]['Run OEM BREX']);
            await this.base.optselector(dmLoc.dm[0]['Run AIRLINE BREX'],testdata.s10000d41[0]['Run AIRLINE BREX']);
            await this.base.uploadfile(dmLoc.dm[0].Packages,testdata.s10000d41[0].Packages);
            await this.base.clickbtn(dmLoc.dm[0].importbtn);
            await this.base.clickbtn(dmLoc.dm[0].alertimport);
            await this.base.selectprodiv(testdata.s10000d41[0]['Revision Name'],'OK');
            await this.page.waitForTimeout(30000); 
            await this.page.reload();
            await this.base.selectprodiv(testdata.s10000d41[0]['Revision Name'],'View Report');
            await this.base.printreport(dmLoc.dm[0].report);
        }
        else{
            await this.base.clickbtn(dmLoc.dm[0].add);
            await this.base.setValue(dmLoc.dm[0]['Revision-Name'],testdata.s10000d41[0]['Revision Name']);
            await this.base.optselector(dmLoc.dm[0]['Revision-Type'],testdata.s10000d41[0]['Revision Type']);
            await this.base.checkbox(dmLoc.dm[0]['Run OEM BREX'],testdata.s10000d41[0]['Run OEM BREX']);
            await this.base.optselector(dmLoc.dm[0]['Run AIRLINE BREX'],testdata.s10000d41[0]['Run AIRLINE BREX']);
            await this.base.uploadfile(dmLoc.dm[0].Packages,testdata.s10000d41[0].Packages);
            await this.base.clickbtn(dmLoc.dm[0].importbtn);
            await this.base.clickbtn(dmLoc.dm[0].alertimport);
            await this.base.selectprodiv(testdata.s10000d41[0]['Revision Name'],'OK');
            await this.page.waitForTimeout(30000); 
            await this.page.reload();
            await this.base.selectprodiv(testdata.s10000d41[0]['Revision Name'],'View Report');
            await this.base.printreport(dmLoc.dm[0].report);
        }
    }
    async contimport(){
        await this.base.contimport(dmLoc.dm[0].contimport);
    }
    async stopimport(){
        await this.base.stopimport(dmLoc.dm[0].stopimport);
    }

}