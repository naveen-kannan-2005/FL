const fs = require("fs");
const path = require("path");
const ExcelJS = require("exceljs");

// Usage:
// node json-to-excel.js "<repoRoot>" "<jsonRelativePath>" "<outputXlsxPath>"
//
// Example:
// node json-to-excel.js "D:\Pinpointclient_e2e\pinpoint-client-automation-e2e" "config\mfrrrpatch1.json" "file-list.xlsx"

async function main() {
  const repoRoot = process.argv[2];
  const jsonRelPath = process.argv[3];
  const outputXlsx = process.argv[4] || "file-list.xlsx";

  if (!repoRoot || !jsonRelPath) {
    console.log(`❌ Missing args.
✅ Usage:
  node json-to-excel.js "<repoRoot>" "<jsonRelativePath>" "<outputXlsxPath>"

Example:
  node json-to-excel.js "D:\\Pinpointclient_e2e\\pinpoint-client-automation-e2e" "config\\mfrrrpatch1.json" "file-list.xlsx"
`);
    process.exit(1);
  }

  const jsonPath = path.resolve(repoRoot, jsonRelPath);

  if (!fs.existsSync(jsonPath)) {
    console.log(`❌ JSON file not found: ${jsonPath}`);
    process.exit(1);
  }

  const config = JSON.parse(fs.readFileSync(jsonPath, "utf8"));
  const files = config.script_name;

  if (!Array.isArray(files) || files.length === 0) {
    console.log("❌ JSON does not contain a non-empty `script_name` array.");
    process.exit(1);
  }

  // Create workbook + sheet
  const workbook = new ExcelJS.Workbook();
  const sheet = workbook.addWorksheet("Files");

  // Header row
  sheet.columns = [
    { header: "S.No", key: "sno", width: 10 },
    { header: "File Name", key: "file", width: 80 }
  ];

  // Style header
  sheet.getRow(1).font = { bold: true };
  sheet.views = [{ state: "frozen", ySplit: 1 }];

  // Add rows (row-wise file names)
  files.forEach((fileName, idx) => {
    sheet.addRow({ sno: idx + 1, file: fileName });
  });

  // Optional: add filter
  sheet.autoFilter = {
    from: { row: 1, column: 1 },
    to: { row: 1, column: 2 }
  };

  // Save
  const outPath = path.resolve(process.cwd(), outputXlsx);
  await workbook.xlsx.writeFile(outPath);

  console.log(`✅ Excel created: ${outPath}`);
  console.log(`✅ Total files written: ${files.length}`);
}

main().catch((err) => {
  console.error("❌ Error:", err.message);
  process.exit(1);
});