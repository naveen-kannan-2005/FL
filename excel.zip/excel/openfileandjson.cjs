"use strict";

/**
 * spec_nodes_values_columns_excel.cjs
 *
 * 1 row per spec.
 * Columns:
 *   SpecFileName | Nodes_1 | Nodes_2 | Nodes_3 | ...
 *
 * "Nodes_*" columns contain the VALUE of key "Nodes" (not path).
 * Value is stringified (preview + truncated) to fit Excel cell limits.
 *
 * Usage:
 *  node spec_nodes_values_columns_excel.cjs "<repoRoot>" "<configJsonRelativePath>"
 *        [--out=SpecNodesValues.xlsx] [--limit=150] [--match=TestData]
 *        [--nodes-items=5] [--nodes-depth=4] [--maxchars=30000] [--case-insensitive-nodes]
 *
 * Examples:
 *  node spec_nodes_values_columns_excel.cjs "D:\Pinpointclient_e2e\pinpoint-client-automation-e2e" "config\mfrrrpatch1.json" --out=SpecNodesValues.xlsx
 *  node spec_nodes_values_columns_excel.cjs "D:\Pinpointclient_e2e\pinpoint-client-automation-e2e" "config\mfrrrpatch1.json" --limit=5 --nodes-items=10 --nodes-depth=6
 */

const fs = require("fs");
const path = require("path");
const ExcelJS = require("exceljs");

// -------- args --------
const repoRoot = process.argv[2];
const jsonRelPath = process.argv[3];

const outArg = process.argv.find(a => a.startsWith("--out="));
const outXlsx = outArg ? outArg.split("=").slice(1).join("=") : "SpecNodesValues.xlsx";

const limitArg = process.argv.find(a => a.startsWith("--limit="));
const limit = limitArg ? Number(limitArg.split("=")[1]) : Infinity;

const matchArg = process.argv.find(a => a.startsWith("--match="));
const matchText = matchArg ? matchArg.split("=").slice(1).join("=") : "TestData";

// preview config
const itemsArg = process.argv.find(a => a.startsWith("--nodes-items="));
const nodesItems = itemsArg ? Number(itemsArg.split("=")[1]) : 5;

const depthArg = process.argv.find(a => a.startsWith("--nodes-depth="));
const nodesDepth = depthArg ? Number(depthArg.split("=")[1]) : 4;

const maxArg = process.argv.find(a => a.startsWith("--maxchars="));
const maxChars = maxArg ? Number(maxArg.split("=")[1]) : 30000; // keep < 32767

const caseInsensitiveNodes = process.argv.includes("--case-insensitive-nodes");

if (!repoRoot || !jsonRelPath) {
  console.log(`❌ Missing args.
✅ Usage:
  node spec_nodes_values_columns_excel.cjs "<repoRoot>" "<configJsonRelativePath>"
        [--out=SpecNodesValues.xlsx] [--limit=150] [--match=TestData]
        [--nodes-items=5] [--nodes-depth=4] [--maxchars=30000] [--case-insensitive-nodes]
`);
  process.exit(1);
}

const repoRootAbs = path.resolve(repoRoot);
const configPath = path.resolve(repoRootAbs, jsonRelPath);

// -------- helpers --------
function readJsonFile(p) {
  const raw = fs.readFileSync(p, "utf8").replace(/^\uFEFF/, "");
  return JSON.parse(raw);
}

function isSkippableDir(name) {
  return ["node_modules", ".git", "dist", "build", "out", ".next", "coverage"].includes(name);
}

function findFileRecursively(rootDir, targetFileName) {
  const stack = [rootDir];
  while (stack.length) {
    const current = stack.pop();
    let entries;
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const entry of entries) {
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) {
        if (!isSkippableDir(entry.name)) stack.push(full);
      } else if (entry.isFile() && entry.name === targetFileName) {
        return full;
      }
    }
  }
  return null;
}

function normalizeModule(p) {
  return String(p || "").replace(/\\/g, "/").trim();
}

function extractImportStatements(text) {
  if (text && text.charCodeAt(0) === 0xfeff) text = text.slice(1);
  const lines = text.split(/\r?\n/);
  const statements = [];
  let capturing = false;
  let buf = "";

  for (const line of lines) {
    if (!capturing) {
      if (/^\s*import\b/.test(line)) {
        capturing = true;
        buf = line;
        if (line.includes(";")) {
          statements.push(buf.trim());
          capturing = false;
          buf = "";
        }
      }
    } else {
      buf += "\n" + line;
      if (line.includes(";")) {
        statements.push(buf.trim());
        capturing = false;
        buf = "";
      }
    }
  }
  if (capturing && buf.trim()) statements.push(buf.trim());
  return statements;
}

function getModuleFromImportStatement(stmt) {
  const fromMatch = stmt.match(/from\s*(['"])([^'"]+)\1/);
  if (fromMatch) return normalizeModule(fromMatch[2]);

  const onlyMatch = stmt.match(/^\s*import\s*(['"])([^'"]+)\1/);
  if (onlyMatch) return normalizeModule(onlyMatch[2]);

  return null;
}

function resolveModuleToFile(specFullPath, modulePathRaw) {
  const modulePath = normalizeModule(modulePathRaw);
  const specDir = path.dirname(specFullPath);

  const candidates = [];
  const addWithJsonFallback = (p) => {
    candidates.push(p);
    if (!path.extname(p)) candidates.push(p + ".json");
  };

  if (modulePath.startsWith(".")) {
    addWithJsonFallback(path.resolve(specDir, modulePath));
  } else if (modulePath.startsWith("/")) {
    addWithJsonFallback(path.resolve(repoRootAbs, modulePath.slice(1)));
  } else {
    addWithJsonFallback(path.resolve(repoRootAbs, modulePath));
  }

  for (const c of candidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) return c;
    } catch {}
  }

  const baseName = path.basename(
    modulePath.toLowerCase().endsWith(".json") ? modulePath : modulePath + ".json"
  );
  return findFileRecursively(repoRootAbs, baseName);
}

/**
 * ✅ Find VALUES of key "Nodes" anywhere in JSON (deep scan)
 * - exact key match: "Nodes" (default)
 * - if --case-insensitive-nodes, matches "nodes"/"NODES"/etc.
 * Returns array of values (could be array/object/string)
 */
function findNodesValues(root) {
  const results = [];
  const stack = [root];
  const matchKey = (k) => {
    if (!caseInsensitiveNodes) return k === "Nodes";
    return String(k).toLowerCase() === "nodes";
  };

  while (stack.length) {
    const value = stack.pop();
    if (value === null || value === undefined) continue;

    if (Array.isArray(value)) {
      for (let i = value.length - 1; i >= 0; i--) stack.push(value[i]);
      continue;
    }

    if (typeof value === "object") {
      const entries = Object.entries(value);
      for (let i = entries.length - 1; i >= 0; i--) {
        const [k, v] = entries[i];
        if (matchKey(k)) results.push(v);
        stack.push(v);
      }
    }
  }

  return results;
}

/**
 * Create a safe string for Excel cell:
 * - If Nodes is array: keep first nodesItems
 * - If object: keep limited depth by trimming nested levels
 * - Truncate to maxChars (safe < 32767)
 */
function toExcelCellString(nodesValue) {
  let preview = nodesValue;

  // Preview arrays: keep first N items
  if (Array.isArray(preview)) {
    preview = preview.slice(0, Math.max(0, nodesItems));
  }

  // Stringify with safe depth-limiter (prevents huge output)
  const seen = new WeakSet();
  const depthLimit = Math.max(1, nodesDepth);

  function stringifyWithDepth(val, depth) {
    if (val === null || val === undefined) return val;
    if (typeof val !== "object") return val;

    if (seen.has(val)) return "[Circular]";
    seen.add(val);

    if (depth <= 0) return "[MaxDepth]";

    if (Array.isArray(val)) {
      return val.slice(0, nodesItems).map(x => stringifyWithDepth(x, depth - 1));
    }

    const out = {};
    for (const [k, v] of Object.entries(val)) {
      out[k] = stringifyWithDepth(v, depth - 1);
    }
    return out;
  }

  const limited = stringifyWithDepth(preview, depthLimit);

  let str;
  try {
    str = JSON.stringify(limited);
  } catch {
    str = String(limited);
  }

  if (str.length > maxChars) {
    str = str.slice(0, maxChars) + `... (TRUNCATED, len=${str.length})`;
  }
  return str;
}

// -------- main --------
async function main() {
  if (!fs.existsSync(configPath)) {
    console.log(`❌ Config JSON not found: ${configPath}`);
    process.exit(1);
  }

  const cfg = readJsonFile(configPath);
  const specs = cfg.script_name;

  if (!Array.isArray(specs) || specs.length === 0) {
    console.log("❌ `script_name` missing/empty in config JSON.");
    process.exit(1);
  }

  const maxSpecs = Math.min(specs.length, limit);
  const matchLower = matchText.toLowerCase();

  console.log(`✅ Specs: ${specs.length} | processing=${maxSpecs} | match="${matchText}"`);
  console.log(`✅ Output: ${path.resolve(outXlsx)}`);

  // Pass 1: collect Nodes VALUES per spec and find max number
  const perSpec = []; // { specFile, nodesValues: string[] }
  let maxNodesCols = 0;

  for (let i = 0; i < maxSpecs; i++) {
    const specFile = specs[i];
    const specPath = findFileRecursively(repoRootAbs, specFile);

    if (!specPath) {
      perSpec.push({ specFile, nodesValues: [] });
      continue;
    }

    const specText = fs.readFileSync(specPath, "utf8");
    const importStatements = extractImportStatements(specText);
    const modules = importStatements.map(getModuleFromImportStatement).filter(Boolean);

    // Get TestData imports
    const matchedModules = modules.filter(m => m.toLowerCase().includes(matchLower));

    const allValues = [];

    for (const mod of matchedModules) {
      const jsonPath = resolveModuleToFile(specPath, mod);
      if (!jsonPath || !fs.existsSync(jsonPath)) continue;

      let jsonData;
      try {
        jsonData = readJsonFile(jsonPath);
      } catch {
        continue;
      }

      // ✅ Get actual "Nodes" values
      const values = findNodesValues(jsonData);

      for (const v of values) {
        allValues.push(toExcelCellString(v));
      }
    }

    // Remove duplicates to avoid repeating same Nodes content
    const unique = Array.from(new Set(allValues));

    perSpec.push({ specFile, nodesValues: unique });
    if (unique.length > maxNodesCols) maxNodesCols = unique.length;
  }

  console.log(`✅ Max number of "Nodes" values in a single spec: ${maxNodesCols}`);

  // Pass 2: write Excel with dynamic columns
  const wb = new ExcelJS.Workbook();
  const sheet = wb.addWorksheet("SpecNodesValues");

  const columns = [{ header: "SpecFileName", key: "spec", width: 55 }];
  for (let i = 1; i <= maxNodesCols; i++) {
    columns.push({ header: `Nodes_${i}`, key: `n${i}`, width: 90 });
  }

  sheet.columns = columns;
  sheet.getRow(1).font = { bold: true };
  sheet.views = [{ state: "frozen", ySplit: 1 }];
  sheet.autoFilter = {
    from: { row: 1, column: 1 },
    to: { row: 1, column: columns.length }
  };

  for (const item of perSpec) {
    const row = { spec: item.specFile };
    for (let i = 0; i < maxNodesCols; i++) {
      row[`n${i + 1}`] = item.nodesValues[i] || "";
    }
    sheet.addRow(row);
  }

  await wb.xlsx.writeFile(path.resolve(process.cwd(), outXlsx));
  console.log(`🎉 Done! Excel created: ${path.resolve(process.cwd(), outXlsx)}`);
}

main().catch((e) => {
  console.error("❌ Error:", e.message);
  process.exit(1);
});
``