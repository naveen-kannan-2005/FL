"use strict";

/**
 * final_fixed.cjs
 *
 * 1 row per spec.
 * Columns:
 *   SpecFileName | Nodes_1 | Nodes_2 | Nodes_3 | ...
 *
 * IMPORTANT:
 *  - We scan the entire TestData JSON and collect EVERY key whose name contains "Nodes" (case-insensitive)
 *    e.g. Nodes, libA.Nodes, node1.Nodes, childNodes, etc.
 *  - For EACH occurrence, we store ONLY the FIRST value:
 *      - if value is array -> first element
 *      - if value is string with commas -> text before first comma
 *      - if value is a JSON-stringified array -> parse and take first
 *  - We DO NOT deduplicate, so column count stays high like your earlier output.
 *
 * Usage:
 *   node final_fixed.cjs "<repoRoot>" "<configJsonRelativePath>" [--out=mfrrrpatch1.xlsx] [--limit=150] [--match=TestData]
 *
 * Example:
 *   node final_fixed.cjs "D:\Pinpointclient_e2e\pinpoint-client-automation-e2e" "config\mfrrrpatch1.json" --out=mfrrrpatch1.xlsx
 */

const fs = require("fs");
const path = require("path");
const ExcelJS = require("exceljs");

// -------- args --------
const repoRoot = process.argv[2];
const jsonRelPath = process.argv[3];

const outArg = process.argv.find(a => a.startsWith("--out="));
const outXlsx = outArg ? outArg.split("=").slice(1).join("=") : "SpecNodesFirstOnly.xlsx";

const limitArg = process.argv.find(a => a.startsWith("--limit="));
const limit = limitArg ? Number(limitArg.split("=")[1]) : Infinity;

const matchArg = process.argv.find(a => a.startsWith("--match="));
const matchText = matchArg ? matchArg.split("=").slice(1).join("=") : "TestData";

if (!repoRoot || !jsonRelPath) {
  console.log(`❌ Missing args.
✅ Usage:
  node final_fixed.cjs "<repoRoot>" "<configJsonRelativePath>" [--out=mfrrrpatch1.xlsx] [--limit=150] [--match=TestData]
`);
  process.exit(1);
}

const repoRootAbs = path.resolve(repoRoot);
const configPath = path.resolve(repoRootAbs, jsonRelPath);

// -------- helpers --------
function readJsonFile(p) {
  const raw = fs.readFileSync(p, "utf8").replace(/^\uFEFF/, "");
  return JSON.parse(raw);
}

function isSkippableDir(name) {
  return ["node_modules", ".git", "dist", "build", "out", ".next", "coverage"].includes(name);
}

function findFileRecursively(rootDir, targetFileName) {
  const stack = [rootDir];
  while (stack.length) {
    const current = stack.pop();
    let entries;
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      continue;
    }
    for (const entry of entries) {
      const full = path.join(current, entry.name);
      if (entry.isDirectory()) {
        if (!isSkippableDir(entry.name)) stack.push(full);
      } else if (entry.isFile() && entry.name === targetFileName) {
        return full;
      }
    }
  }
  return null;
}

function normalizeModule(p) {
  return String(p || "").replace(/\\/g, "/").trim();
}

function extractImportStatements(text) {
  if (text && text.charCodeAt(0) === 0xfeff) text = text.slice(1);
  const lines = text.split(/\r?\n/);
  const statements = [];
  let capturing = false;
  let buf = "";

  for (const line of lines) {
    if (!capturing) {
      if (/^\s*import\b/.test(line)) {
        capturing = true;
        buf = line;
        if (line.includes(";")) {
          statements.push(buf.trim());
          capturing = false;
          buf = "";
        }
      }
    } else {
      buf += "\n" + line;
      if (line.includes(";")) {
        statements.push(buf.trim());
        capturing = false;
        buf = "";
      }
    }
  }
  if (capturing && buf.trim()) statements.push(buf.trim());
  return statements;
}

function getModuleFromImportStatement(stmt) {
  const fromMatch = stmt.match(/from\s*(['"])([^'"]+)\1/);
  if (fromMatch) return normalizeModule(fromMatch[2]);

  const onlyMatch = stmt.match(/^\s*import\s*(['"])([^'"]+)\1/);
  if (onlyMatch) return normalizeModule(onlyMatch[2]);

  return null;
}

function resolveModuleToFile(specFullPath, modulePathRaw) {
  const modulePath = normalizeModule(modulePathRaw);
  const specDir = path.dirname(specFullPath);

  const candidates = [];
  const addWithJsonFallback = (p) => {
    candidates.push(p);
    if (!path.extname(p)) candidates.push(p + ".json");
  };

  if (modulePath.startsWith(".")) {
    addWithJsonFallback(path.resolve(specDir, modulePath));
  } else if (modulePath.startsWith("/")) {
    addWithJsonFallback(path.resolve(repoRootAbs, modulePath.slice(1)));
  } else {
    addWithJsonFallback(path.resolve(repoRootAbs, modulePath));
  }

  for (const c of candidates) {
    try {
      if (fs.existsSync(c) && fs.statSync(c).isFile()) return c;
    } catch {}
  }

  const baseName = path.basename(
    modulePath.toLowerCase().endsWith(".json") ? modulePath : modulePath + ".json"
  );
  return findFileRecursively(repoRootAbs, baseName);
}

/**
 * FIRST-ONLY FILTER:
 * - array -> first element
 * - string -> before comma
 * - stringified json array -> parse and take first
 */
function firstOnlyFromNodesValue(v) {
  if (v === null || v === undefined) return "";

  if (Array.isArray(v)) {
    return firstOnlyFromNodesValue(v[0]);
  }

  if (typeof v === "string") {
    const s = v.trim();
    if (!s) return "";

    // If looks like JSON, try parse
    if ((s.startsWith("[") && s.endsWith("]")) || (s.startsWith("{") && s.endsWith("}"))) {
      try {
        const parsed = JSON.parse(s);
        return firstOnlyFromNodesValue(parsed);
      } catch {
        // ignore
      }
    }

    // split by comma
    return s.split(",")[0].trim();
  }

  if (typeof v === "number" || typeof v === "boolean") return String(v);

  // object fallback
  if (typeof v === "object") {
    // try some common fields first
    if (typeof v.Node === "string") return v.Node.split(",")[0].trim();
    if (typeof v.Name === "string") return v.Name.split(",")[0].trim();
    if (typeof v.id === "string") return v.id.split(",")[0].trim();
    return "[Object]";
  }

  return String(v).trim();
}

/**
 * ✅ Collect FIRST-only values for EVERY key whose name contains "Nodes" (case-insensitive),
 * anywhere in the JSON (deep scan).
 *
 * Returns an array of first-only values IN THE ORDER FOUND.
 */
function collectNodesFirstValues(root) {
  const out = [];
  const stack = [root];

  while (stack.length) {
    const value = stack.pop();
    if (value === null || value === undefined) continue;

    if (Array.isArray(value)) {
      for (let i = value.length - 1; i >= 0; i--) stack.push(value[i]);
      continue;
    }

    if (typeof value === "object") {
      const entries = Object.entries(value);
      for (let i = entries.length - 1; i >= 0; i--) {
        const [k, v] = entries[i];

        // KEY CONTAINS "nodes" anywhere (this restores your earlier "higher columns")
        if (String(k).toLowerCase().includes("nodes")) {
          const first = firstOnlyFromNodesValue(v);
          if (first) out.push(first);
        }

        stack.push(v);
      }
    }
  }

  return out;
}

// -------- main --------
async function main() {
  if (!fs.existsSync(configPath)) {
    console.log(`❌ Config JSON not found: ${configPath}`);
    process.exit(1);
  }

  const cfg = readJsonFile(configPath);
  const specs = cfg.script_name;

  if (!Array.isArray(specs) || specs.length === 0) {
    console.log("❌ `script_name` missing/empty in config JSON.");
    process.exit(1);
  }

  const maxSpecs = Math.min(specs.length, limit);
  const matchLower = matchText.toLowerCase();

  console.log(`✅ Specs: ${specs.length} | processing=${maxSpecs} | match="${matchText}"`);
  console.log(`✅ Output: ${path.resolve(outXlsx)}`);

  // Pass 1: per spec collect all first-only values and compute max columns
  const perSpec = []; // { specFile, nodesValues: string[] }
  let maxNodesCols = 0;

  for (let i = 0; i < maxSpecs; i++) {
    const specFile = specs[i];
    const specPath = findFileRecursively(repoRootAbs, specFile);

    if (!specPath) {
      perSpec.push({ specFile, nodesValues: [] });
      continue;
    }

    const specText = fs.readFileSync(specPath, "utf8");
    const importStatements = extractImportStatements(specText);
    const modules = importStatements.map(getModuleFromImportStatement).filter(Boolean);

    const matchedModules = modules.filter(m => m.toLowerCase().includes(matchLower));

    const nodesValues = [];

    for (const mod of matchedModules) {
      const jsonPath = resolveModuleToFile(specPath, mod);
      if (!jsonPath || !fs.existsSync(jsonPath)) continue;

      let jsonData;
      try {
        jsonData = readJsonFile(jsonPath);
      } catch {
        continue;
      }

      // ✅ Collect first-only values from ALL "*Nodes*" keys (no dedupe)
      const vals = collectNodesFirstValues(jsonData);
      nodesValues.push(...vals);
    }

    perSpec.push({ specFile, nodesValues });
    if (nodesValues.length > maxNodesCols) maxNodesCols = nodesValues.length;
  }

  console.log(`✅ Max number of FIRST-ONLY Nodes values in a single spec: ${maxNodesCols}`);

  // Pass 2: write Excel
  const wb = new ExcelJS.Workbook();
  const sheet = wb.addWorksheet("SpecNodesFirstOnly");

  const columns = [{ header: "SpecFileName", key: "spec", width: 55 }];
  for (let i = 1; i <= maxNodesCols; i++) {
    columns.push({ header: `Nodes_${i}`, key: `n${i}`, width: 40 });
  }

  sheet.columns = columns;
  sheet.getRow(1).font = { bold: true };
  sheet.views = [{ state: "frozen", ySplit: 1 }];
  sheet.autoFilter = {
    from: { row: 1, column: 1 },
    to: { row: 1, column: columns.length }
  };

  for (const item of perSpec) {
    const row = { spec: item.specFile };
    for (let i = 0; i < maxNodesCols; i++) {
      row[`n${i + 1}`] = item.nodesValues[i] || "";
    }
    sheet.addRow(row);
  }

  await wb.xlsx.writeFile(path.resolve(process.cwd(), outXlsx));
  console.log(`🎉 Done! Excel created: ${path.resolve(process.cwd(), outXlsx)}`);
}

main().catch((e) => {
  console.error("❌ Error:", e.message);
  process.exit(1);
});