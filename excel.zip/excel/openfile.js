// openFromJson.js
// Usage:
//   node openFromJson.js "C:\path\to\repo" "config/mfrmpatch1.json"
//   node openFromJson.js "/path/to/repo" "config/mfrmpatch1.json"

import fs from "fs";
import path from "path";
import { spawn } from "child_process";

const repoRoot = process.argv[2];
const jsonRelPath = process.argv[3];

if (!repoRoot || !jsonRelPath) {
  console.log(`❌ Missing args.
✅ Usage:
  node openFromJson.js "<repoRoot>" "<jsonRelativePath>"

Example:
  node openFromJson.js "." "config/mfrmpatch1.json"
`);
  process.exit(1);
}

const jsonPath = path.resolve(repoRoot, jsonRelPath);

function readJson(p) {
  return JSON.parse(fs.readFileSync(p, "utf8"));
}

function isSkippableDir(name) {
  return ["node_modules", ".git", "dist", "build", "out", ".next", "coverage"].includes(name);
}

function findFileRecursively(rootDir, targetFileName) {
  const stack = [rootDir];

  while (stack.length) {
    const current = stack.pop();
    let entries;
    try {
      entries = fs.readdirSync(current, { withFileTypes: true });
    } catch {
      continue;
    }

    for (const entry of entries) {
      const full = path.join(current, entry.name);

      if (entry.isDirectory()) {
        if (!isSkippableDir(entry.name)) stack.push(full);
      } else if (entry.isFile()) {
        if (entry.name === targetFileName) return full;
      }
    }
  }
  return null;
}

function openInVSCode(filePath) {
  return new Promise((resolve, reject) => {
    // --reuse-window keeps it in the same VS Code window
    // -g opens at a location (line:col). We'll open at 1:1
    const p = spawn("code", ["--reuse-window", "-g", `${filePath}:1:1`], {
      stdio: "ignore",
      shell: true
    });

    p.on("error", reject);
    p.on("close", (code) => (code === 0 ? resolve() : reject(new Error(`code exited ${code}`))));
  });
}

async function main() {
  const config = readJson(jsonPath);
  const files = config.script_name;

  if (!Array.isArray(files) || files.length === 0) {
    console.log("❌ JSON does not contain a non-empty `script_name` array.");
    return;
  }

  console.log(`✅ Found ${files.length} file names in JSON`);
  const missing = [];

  for (let i = 0; i < files.length; i++) {
    const fileName = files[i];
    const fullPath = findFileRecursively(path.resolve(repoRoot), fileName);

    if (!fullPath) {
      console.log(`❌ Not found: ${fileName}`);
      missing.push(fileName);
      continue;
    }

    console.log(`✅ Opening (${i + 1}/${files.length}): ${fileName}`);
    await openInVSCode(fullPath);

    // small delay so VS Code has time to open the editor
    await new Promise((r) => setTimeout(r, 150));
  }

  if (missing.length) {
    console.log("\n⚠️ Missing files:");
    missing.forEach((m) => console.log(" - " + m));
  } else {
    console.log("\n🎉 All files opened!");
  }
}

main().catch((e) => console.error("❌ Error:", e.message));